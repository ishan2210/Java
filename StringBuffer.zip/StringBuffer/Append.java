package StringBuffer;
public class Append 
{
    public static void main(String args[])
    {
        StringBuffer str=new StringBuffer("Hello");
        str.append("Java");
        System.out.println(str);
    }
}
