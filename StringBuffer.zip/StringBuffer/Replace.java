package StringBuffer;
public class Replace 
{
    public static void main(String args[])
    {
        StringBuffer str=new StringBuffer("Hello");
        str.replace(1,4,"Java");
        System.out.println(str);
    }
}
