package StringBuffer;
public class Delete 
{
    public static void main(String args[])
    {
        StringBuffer str=new StringBuffer("Hello");
        str.delete(1,2);
        System.out.println(str);
    }
}
