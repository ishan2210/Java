package StringBuffer;
public class Reverse 
{
    public static void main(String args[])
    {
        StringBuffer str=new StringBuffer("Dhruv");
        System.out.println(str.reverse());
    }
}
