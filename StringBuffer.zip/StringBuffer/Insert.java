package StringBuffer;
public class Insert 
{
    public static void main(String args[])
    {
        StringBuffer str=new StringBuffer("Hello");
        str.insert(1,"Java");
        System.out.println(str);
    }
}
