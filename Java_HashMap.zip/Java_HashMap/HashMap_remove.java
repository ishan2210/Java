package Java_HashMap;
import java.util.*;

public class HashMap_remove {
   public static void main(String args[])
   {
       HashMap <Integer,String> map=new HashMap<Integer,String>();
       map.put(101,"Purv");
       map.put(102,"Abhi");
       map.put(103,"Ishan");
       map.put(104,"Rushi");
       System.out.println("List of elements-->"+map);
       map.remove(102);
       System.out.println("After removing 102 element"+map);
       map.remove(103);
       System.out.println("After removing 103 element"+map);
       map.remove(101,"Purv");
       System.out.println("Updated List of Elemenbts"+map);
   }
}
