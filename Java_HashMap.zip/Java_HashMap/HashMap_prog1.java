package Java_HashMap;
import java.util.*;
public class HashMap_prog1 {
    public static void main(String args[])
    {
        HashMap<Integer,String> map=new HashMap<Integer,String>();
        map.put(1,"Mango");
        map.put(2,"Banana");
        map.put(3,"Chickoo");
        map.put(4,"Orange");
        map.put(5,"Grapes");
//        map.put(1,"Kiwi");//duplicate key
        
        System.out.println("Iterating HashMap");
        for(Map.Entry m:map.entrySet())
        {
            System.out.println(m.getKey()+" "+m.getValue());
        }
    }
}
