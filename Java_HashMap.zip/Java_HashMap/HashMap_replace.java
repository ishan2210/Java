package Java_HashMap;
import java.util.*;

public class HashMap_replace {
    public static void main(String args[])
    {
       HashMap<Integer,String> map=new HashMap<Integer,String>();
       map.put(101,"Ishan");
       map.put(102,"Vandan");
       map.put(103,"Darshil");
       System.out.println("Initial List of Elements");
       for(Map.Entry m:map.entrySet())
       {
           System.out.println(m.getKey()+" "+m.getValue());
       }
       System.out.println("-------------------------------------");
       System.out.println("Updated List of Elements");
       map.replace(101,"Purv");
       for(Map.Entry m:map.entrySet())
       {
           System.out.println(m.getKey()+" "+m.getValue());
       }
       
       
       
    }
}
