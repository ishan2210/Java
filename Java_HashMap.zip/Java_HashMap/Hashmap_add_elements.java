package Java_HashMap;
import java.util.*;  
public class Hashmap_add_elements{  
 public static void main(String args[]){  
     
   HashMap<Integer,String> hm=new HashMap<Integer,String>();    
    System.out.println("Initial list of elements: "+hm);  
      hm.put(100,"Jay");    
      hm.put(101,"Purv");    
      hm.put(102,"Abhi");   
       
      
      System.out.println("After adding put() method ");  
      for(Map.Entry m:hm.entrySet()){    
       System.out.println(m.getKey()+" "+m.getValue());    
      }  
        
      
      hm.putIfAbsent(103, "Ishan");  
      System.out.println("After adding putIfAbsent() method ");  
      for(Map.Entry m:hm.entrySet()){    
           System.out.println(m.getKey()+" "+m.getValue());    
          }  
      
      
      HashMap<Integer,String> map=new HashMap<Integer,String>();  
      map.put(104,"Vandan");  
      map.putAll(hm);  
      System.out.println("After adding putAll() method ");  
      for(Map.Entry m:map.entrySet()){    
           System.out.println(m.getKey()+" "+m.getValue());    
          }  
 }  
}  