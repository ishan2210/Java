import java.sql.*;
import java.io.*;
class ImageJDBC
{
	public static void main(String args[])
	{
		try 
		{
          Class.forName("com.mysql.cj.jdbc.Driver");
		  Connection m_connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/form","root","root");


		  String q="insert into images(oic) values(?)";


		  PreparedStatement pstmt=m_connection.prepareStatement(q);


		  FileInputStream fis=new FileInputStream("mypic.jpg");


		  pstmt.setBinaryStream(1,fis,fis.available());
		  pstmt.executeUpdate();

		  System.out.println("done");

		}
		catch(Exception e)
		{

			e.printStackTrace();

		}
	}
}





