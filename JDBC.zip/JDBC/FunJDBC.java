import java.sql.*;
import java.io.*;
class FunJDBC
{
	public static void main(String args[])
	{
		try 
		{
             Class.forName("com.mysql.cj.jdbc.Driver");

             Connection m_connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/form","root","root");

             String q="insert into table1(tname,tcity) values (?,?)";

             PreparedStatement pstmt= m_connection.prepareStatement(q);

             InputStreamReader is=new InputStreamReader(System.in);
             BufferedReader br=new BufferedReader(is);
             System.out.println("Enter the Name-->");
             String name=br.readLine();
             System.out.println("Enter the City-->");
             String city=br.readLine();

             pstmt.setString(1,name);
             pstmt.setString(2,city);

             pstmt.executeUpdate();
             System.out.println("Inserted...");
             m_connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}