import java.sql.*;
class InsertJDBC
{
   public static void main(String args[])
{
	try 
	{
        //Load JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        //Creating Connection
        String url="jdbc:mysql://localhost:3306/form";
        String username="root@localhost";
        String password="root";
        Connection m_connection = DriverManager.getConnection("jdbc:mysql://localhost/form","root","root");

        //create query
        String q="create table table1 (tid int(20) primary key auto_increment,tname varchar(200) not null,tcity varchar(400))";

        //Creating Statement
        Statement stmt=m_connection.createStatement();
        stmt.executeUpdate(q);
        System.out.println("Table Created");
        m_connection.close();

    }
	catch(Exception e)
	{
	   e.printStackTrace();
	}
}
}
