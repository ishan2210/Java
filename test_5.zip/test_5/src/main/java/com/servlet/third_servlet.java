package com.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
public class third_servlet extends HttpServlet
{
    @Override
    public void doGet(HttpServletRequest Request,HttpServletResponse Response)
            throws ServletException,IOException
    {
        System.out.println("Servicing....");
        Response.setContentType("text/html");
        PrintWriter out=Response.getWriter();
        out.println("<h1>this is a get method by servlet</h1>");
    }
}


