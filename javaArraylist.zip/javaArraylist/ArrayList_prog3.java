package javaArraylist;
import java.util.*;

public class ArrayList_prog3 {
    public static void main(String args[])
    {
        ArrayList <String> list=new ArrayList<String>();
        list.add("Mango");
        list.add("Banana");
        list.add("Apple");
        list.add("Guava");
        
        for(String fruit:list)
         System.out.println(fruit);
    }
}
