package javaArraylist;
import java.util.*;
public class ArrayList_prog2 {
    public static void main(String args[])
    {
        ArrayList<String> list=new ArrayList<String>();
        list.add("Mango");
        list.add("Apple");
        list.add("Grapes");
        list.add("Orange");
        Iterator itr=list.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
        
        
    }
}
