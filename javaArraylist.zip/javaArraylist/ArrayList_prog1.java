package javaArraylist;
import java.util.*;
public class ArrayList_prog1 {
    public static void main(String args[])
    {
       ArrayList<String> list=new ArrayList<String>();
       list.add("Mango");
       list.add("Banana");
       list.add("Grapes");
       list.add("Apple");
       System.out.println(list);
    }
}
