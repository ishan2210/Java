package javaArraylist;

import java.util.*;  
  
public class ArrayList_sizeCapacity
{  
  
public static void main(String[] args) throws Exception  
{  
       
    ArrayList<Integer> al = new ArrayList<Integer>();  
      
    System.out.println("The size of the array is: " + al.size());  
}  
}  
