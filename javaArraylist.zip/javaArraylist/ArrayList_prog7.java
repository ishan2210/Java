package javaArraylist;
class Student
{
    int rollno;
    String name;
    int age;
    Student(int rollno,String name,int age)
    {
        this.rollno=rollno;
        this.age=age;
        this.name=name;
    }
            
}