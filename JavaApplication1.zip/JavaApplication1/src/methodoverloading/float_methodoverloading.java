package methodoverloading;
import java.util.*;

class demo_method2
{
    float a,b,c;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A-->");
        a=s.nextFloat();
        System.out.println("Enter the Value of B-->");
        b=s.nextFloat();
        System.out.println("Enter the Value of C-->");
        c=s.nextFloat();     
    }
    void ab(float a)
    {
        System.out.println("Value of A is-->"+a);
    }
    void ab(float b,float c)
    {
        System.out.println("Value of B is-->"+b);
        System.out.println("Value of C is-->"+c);
    }  
}
public class float_methodoverloading {
    public static void main(String args[])
    {
        demo_method2 obj=new demo_method2();
        obj.getdata();
        obj.ab(obj.a);
        obj.ab(obj.b,obj.c);
    }
    
    
}
