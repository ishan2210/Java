package methodoverloading;
import java.util.*;
class abc
{
   
    float length,breadth,area,side;
    double radius, area1;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of Length");
        length=s.nextFloat();
        System.out.println("Enter the Value of Breadth");
        breadth=s.nextFloat();
        System.out.println("Enter the Value of Radius");
        radius=s.nextDouble();
    }
    void demo5(float l, float b)
    {
        area=l*b;
        System.out.println("Area of Rectangle is-->"+area);  
    } 
    void demo5(double r)
    {
        area1=3.14*r*r;
        System.out.println("Area of Circle is-->"+area1);
    }
 
    
}
public class area_methodoverloading
{
    public static void main(String args[])
    {
       abc obj=new abc();
       obj.getdata();
       obj.demo5(obj.length, obj.breadth);
       obj.demo5(obj.radius);
       
    }
}