package methodoverloading;
import java.util.*;
class demo_method
{
    Scanner s=new Scanner(System.in);
    int a,b,c;
    void getdata()
    {
      System.out.println("Enter the value of A-->");
      a=s.nextInt();
      System.out.println("Enter the value of B-->");
      b=s.nextInt();
      System.out.println("Enter the Value of C-->");
      c=s.nextInt();
    }
    void ab(int a)
    {
        System.out.println("Value of A is-->"+a);
    }  
    void ab(int b,int c)
    {
        System.out.println("Value of B is-->"+b);
        System.out.println("Value of C is-->"+c);
    } 
}
public class method_overloading
{
    public static void main(String args[])
    {
      demo_method obj= new demo_method();
      obj.getdata();
      obj.ab(obj.a);
      obj.ab(obj.b,obj.c);
    }
    
}







/*package methodoverloading;

class demo_method
{
    void ab(int a)
    {
        System.out.println("Value of A is-->"+a);
    }
    void ab(int b,int c)
    {
        System.out.println("Value of B is-->"+b);
        System.out.println("Value of C is-->"+c);
    }
    void ab(float a)
    {
        System.out.println("Value of A is-->"+a);
    }   
}
public class method_overloading {
    
    public static void main(String args[])
    {
        demo_method obj=new demo_method();
        obj.ab(1);
        obj.ab(4, 5);
        obj.ab(10.3f);
        
    }
    
    
}
*/