/*Write a program to do sum of command line
argument passed two Double numbers.*/


public class double_numbers {
    public static void main(String args[])
    {
        double a=Integer.parseInt(args[0]);
        double b=Integer.parseInt(args[1]);
   
        System.out.println("Value of A-->"+a);
        System.out.println("Value of B-->"+b);
        System.out.println("Addition of Two Numbers"+(a+b));
    }
}
