package cli;
public class cli_hello
{
 public static void main(String args[])
{
   
   /*int a=Integer.parseInt(args[0]);
   int b=Integer.parseInt(args[1]);

  System.out.println("Value of A is"+a);
  System.out.println("Value of B is"+b);


System.out.println("Addition of Two Numbers"+(a+b));
*/
    
    String a=args[0];
    String b=args[1];
    
    System.out.println("Value of A IS-->"+a);
    System.out.println("Value of B IS-->"+b);
}
}