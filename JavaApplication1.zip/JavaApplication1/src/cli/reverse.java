/*Write a Java program which read number from command 
line and print that number in reverse order.*/



public class reverse {
    public static void main(String args[])
    {
        int i,b,sum=0;
        int a=Integer.parseInt(args[0]);
        for(i=a;i>0;i=i/10)
        {
            b=i%10;
            sum=sum*10+b;
        }
        System.out.println("Reverse Number"+sum);
    }
}
