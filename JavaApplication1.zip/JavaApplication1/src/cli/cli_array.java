package cli;

public class cli_array {
    public static void main(String args[])
    {
       int i;
       int a1[]=new int[args.length];
       for(i=0;i<args.length;i++)
       {
         a1[i]=Integer.parseInt(args[i]);
       }
       System.out.println("Given Array Elements");
       for(i=0;i<args.length;i++)
       {
           System.out.println(a1[i]);
       }
       
    }
}

