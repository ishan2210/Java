/*Write a program which takes five numbers as command line argument 
from user, store them in one dimensional 
array and display count of negative numbers.*/


public class negative_no {
    public static void main(String args[])
    {
        int i,count=0;
        int a[]=new int[args.length];
        for(i=0;i<args.length;i++)
        {
            a[i]=Integer.parseInt(args[i]);
        }
        for(i=0;i<args.length;i++)
        {
            if(a[i]<0)
            {
                System.out.println(a[i]);
                count++;
            }
        }
       System.out.println("Negative no  are-->"+count);
    }
}
