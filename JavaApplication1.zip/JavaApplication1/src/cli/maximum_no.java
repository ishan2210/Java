/*Write a program to take three numbers as command line argument. 
Display the maximum among them?*/


public class maximum_no {
    public static void main(String args[])
    {
        int i,max=0;
        int a[]=new int[args.length];
        for(i=0;i<args.length;i++)
        {
            max=a[0];
            if(a[i]>max)
            {
                max=a[i];
            }  
        }
        System.out.println("Maximum Number is-->"+max);
    }
}
