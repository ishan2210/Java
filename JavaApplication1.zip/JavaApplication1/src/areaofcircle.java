import java.util.*;
public class areaofcircle {
    
    public static void main(String args[]){
        
        float radius,area;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter Radius");
        radius=s.nextFloat();
        area=(float) (3.14*radius*radius);
        System.out.println("Area of circle is"+area);
    }

}

