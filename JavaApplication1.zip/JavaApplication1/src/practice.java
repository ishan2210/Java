/*public class practice
{
    
    public static void main (String args[])
    {
       String str1="ishan";
       String str2="jay";
       String str3="kansara";
       String str4="kansara";
       System.out.println(str1.equals(str2));
       System.out.println(str3.equals(str4));
    }
}
    */    
import java.io.*;
public class practice
{
    public static void main(String args[]) throws Exception
    {
        String str1;
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        System.out.println("Enter the String-->");
        str1=br.readLine();
        
        System.out.println("Enter the Words");
        String words=br.readLine();
        int i;
        String s1[]=null;
        for(i=0;i<str1.length();i++)
        {
            
        }
        
        
        
    }
}