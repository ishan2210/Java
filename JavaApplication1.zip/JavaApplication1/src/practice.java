public class practice
{
    public static void main(String args[])
    {
        
    }
}