/*public class practice
{
    
    public static void main (String args[])
    {
       String str1="ishan";
       String str2="jay";
       String str3="kansara";
       String str4="kansara";
       System.out.println(str1.equals(str2));
       System.out.println(str3.equals(str4));
    }
}
    */    

public class practice
{
    public static void main(String args[])
    {
        String name="Ishan";
        byte b[]=name.getBytes();
        for(int i=0;i<name.length();i++)
        {
           System.out.println(b[i]);
        }
        String str=new String(b);
        System.out.println(str);
    }
}