package Multi_threading;
class Thread_16 implements Runnable
{
    @Override
    public void run()
    {
        try
        {
            for(int i=1;i<=5;i++)
            {
                Thread.sleep(1000);
                System.out.println("Good Morning");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
class Thread_17 implements Runnable
{
    @Override
    public void run()
    {
        try
        {
            
        }
        catch(Exception e)
        {
          System.out.println("Good Afternoon");  
        }
    }
}

public class multithreading_goodmorning {
    public static void main(String args[])
    {
        
    }
}
