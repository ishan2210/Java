package Multi_threading;
import java.util.*;
class Thread26 extends Thread
{
    @Override
   public void run()
   {
      int size;
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the Size of Memory");
      size=s.nextInt();
      int a[]=new int [size]; 
      int i;
     
      for(i=0;i<=size;i++)
      {
          a[i]=s.nextInt();
      }
   }
}
public class MultiThreading_Array {
    public static void main(String args[])
    {
        Thread26 obj=new Thread26();
        obj.start();
    }
}
