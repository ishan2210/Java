package Multi_threading;
class Thread_9 extends Thread
{
    @Override
    public void run()
    {
        try
        {
            for(int i=1;i<=5;i++)
            {
                System.out.println("Value of i is-->"+i);
                Thread.sleep(500);
            }
        }
        catch(Exception e)
        {
           System.out.println(e);
        }
    }
}
class Thread_10 extends Thread
{
    @Override
    public void run()
    {
        try
        {
           for(int i=1;i<=5;i++)
           {
               System.out.println("Value of j is-->"+i);
               Thread.sleep(500);
           }
        }
        catch(Exception e)
        {
           System.out.println(e);
        }
    }
}
class Thread_11 extends Thread
{
    @Override
    public void run()
    {
       try
       {
           for(int i=1;i<=5;i++)
           {
               System.out.println("Value of K is-->"+i);
               Thread.sleep(500);
           }
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
    }
}
public class multithreading_itslef_thread_join_method {
    public static void main(String args[])
    {
        Thread_9 obj=new Thread_9();
        obj.start();
        System.out.println("Thread 1 is-->"+obj.isAlive());
        try
        {
           obj.join(); 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        System.out.println("Thread 1 is-->"+obj.isAlive());
        Thread_10 obj1=new Thread_10();
        obj1.start();
        System.out.println("Thread 2 is-->"+obj1.isAlive());
        try
        {
           obj1.join(); 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        System.out.println("Thread 2 is-->"+obj1.isAlive());
        Thread_11 obj2=new Thread_11();
        obj2.start();
        System.out.println("Thread 3 is-->"+obj2.isAlive());
        try
        {
           obj2.join(); 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        System.out.println("Thread 3 is-->"+obj2.isAlive());
        
    }
}
