
package Multi_threading;

class Thread_7 extends Thread
{
    @Override
    public void run()
    {
      try
      {
          for(int i=1;i<=5;i++)
          {
              System.out.println("Value of i is-->"+i);
              Thread.sleep(500);
          }
      }
      catch(Exception e)
      {
          System.out.println(e);
      }
    }
}
public class multithreading_thread_single_class {
    public static void main(String args[])
    {
        Thread_7 obj=new Thread_7();
        obj.start();
        Thread_7 obj1=new Thread_7();
        obj1.start();
    }
}
