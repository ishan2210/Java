package Multi_threading;
import java.util.*;
class Thread_70 extends Thread
{
    Scanner s=new Scanner(System.in);
    @Override
    public void run()
    {
        int n;
        try
        {
         System.out.println("Enter the value of n-->");
         n=s.nextInt();
         
           for(int i=1;i<=n;i++)
           {
              System.out.println("Value is-->"+i);
           }
           Thread.sleep(100);
        }
        catch(Exception e)
        {
           System.out.println(e);
        }
    }
}
class Thread_71 extends Thread
{
    Scanner s=new Scanner(System.in);
 @Override
    public void run()
    {
        int n;
        try
        {
            System.out.println("Enter the value of n-->");
            n=s.nextInt();
            
            for(int i=1;i<=n;i++)
            {
                if(i%2==0)
                {
                    System.out.println("Even Number is-->"+i);
                }
                Thread.sleep(100);
            }
        }
        catch(Exception e)
        {
           System.out.println(e);
        }
    }      
}
class Thread_72 extends Thread
{
    Scanner s=new Scanner(System.in);
//    
    @Override
    public void run()
    {
        int n;
        
           System.out.println("Enter the value of N-->");
           n=s.nextInt();
           
           for(int j=1;j<=n;j++)
           {
              int count=0; 
            for(int i=1;i<=j;i++)
             {
                 if(j%i==0)
                 {
                   count++;
                 }
             }
               if(count==2)
               {
                   count++;
                   System.out.println("Prime Number is-->"+j);
               }
           }
    }
}

public class _thread_oddeven_prime {
    public static void main(String args[])
    {
        Thread_70 obj=new Thread_70();
        obj.start();
        try
        {
            obj.join();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        Thread_71 obj1=new Thread_71();
        obj1.start();
        try
        {
            obj1.join();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        Thread_72 obj2=new Thread_72();
        obj2.start();
    }
}
