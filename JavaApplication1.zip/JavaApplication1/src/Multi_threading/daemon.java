package Multi_threading;
class Thread_73 extends Thread
{
    @Override
    public void run()
    {
        if(Thread.currentThread().isDaemon())
        {
            System.out.println("daemon thread work");
        }
        else
        {
            System.out.println("User Thread Work");
        }
    }
}

public class daemon {
    public static void main(String args[])
    {
        Thread_73 t1=new Thread_73();
        Thread_73 t2=new Thread_73();
        Thread_73 t3=new Thread_73();
        
        t1.setDaemon(true);
        t1.start();
        t2.start();
        t3.start();
    }
}
