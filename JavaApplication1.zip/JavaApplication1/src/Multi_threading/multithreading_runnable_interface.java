
package Multi_threading;

class Thread_5 implements Runnable
{
    Thread obj;
    public Thread_5()
    {
        obj=new Thread(this);
        obj.start();
    }

    @Override
    public void run()
    {
        try
        {
            for(int i=1;i<=5;i++)
            {
                System.out.println("Value of i is-->"+i);
                Thread.sleep(500);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
class Thread_6 implements Runnable
{
    Thread obj1;
    public Thread_6()
    {
        obj1=new Thread(this);
        obj1.start();
    }
    @Override
    public void run()
    {
        try
        {
          for(int i=1;i<=5;i++)
          {
              System.out.println("Value of J is-->"+i);
              Thread.sleep(500);
          }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
public class multithreading_runnable_interface 
{
    public static void main(String args[])
    {
        Thread_5 obj=new Thread_5();
        Thread_6 obj1=new Thread_6();
    }
}

