package Multi_threading;
class Thread_14 extends Thread
{
   int even=0;
   @Override
   public void run()
   {
       try
       {
           for(int i=0;i<=20;i++)
           {
               if(i%2==0)
               {
                   System.out.println("Even number is-->"+i);
               }
               Thread.sleep(100);
               
           } 
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
   }
}
class Thread_15 extends Thread
{
    int odd=0;
    @Override
    public void run()
    {
        try
        {
            for(int i=0;i<=20;i++)
            {
                if(i%2!=0)
                {
                   System.out.println("Odd no is-->"+i); 
                }
                Thread.sleep(100);
                
            }
        }
        catch(Exception e)
        {
           System.out.println(e); 
        }
    }
}
public class multithreading_even_odd {
    public static void main(String args[])
    {
        Thread_15 obj1=new Thread_15();
        obj1.start();
        System.out.println("Thread-1:"+obj1.getName());
        obj1.setName("Bhavesh");
        System.out.println("Thread-1:"+obj1.getName());
        try
        {
           obj1.join(); 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        Thread_14 obj=new Thread_14();
        obj.start();
        System.out.println("Thread-2:"+obj.getName());
        obj.setName("Jain");
        System.out.println("Thread-2:"+obj.getName());
    }
}
