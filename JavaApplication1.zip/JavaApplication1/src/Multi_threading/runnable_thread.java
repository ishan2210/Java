package Multi_threading;
class Thread_2 implements Runnable
{
    Thread obj;
    public Thread_2()
    {
        obj=new Thread(this);
        obj.start();
    }
    @Override
    public void run()
    {
        try
        {
            for(int i=1;i<=5;i++)
            {
                System.out.println("Value of I is-->"+i);
                Thread.sleep(2000);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

public class runnable_thread {
    public static void main(String args[])
    {
        Thread_2 obj=new Thread_2();
    }
}
