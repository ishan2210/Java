package Multi_threading;
import java.lang.*;
class Thread_74 extends Thread
{
    @Override
    public void run()
        {
            System.out.println("Inside the run method");
        }
}
public class priority_thread_ex1 {
    public static void main(String args[])
    {
        Thread_74 t1=new Thread_74();
        Thread_74 t2=new Thread_74();
        Thread_74 t3=new Thread_74();
        
        System.out.println("Normal Priority");
        System.out.println("Priority of the Thread is:"+t1.getPriority());
        System.out.println("Priority of the Thread is:"+t2.getPriority());
        System.out.println("Priority of the Thread is:"+t3.getPriority());
        
        t1.setPriority(6);
        t2.setPriority(8);
        t3.setPriority(7);
        
        System.out.println("--------------------------------------");
        System.out.println("Set Priority");
        System.out.println("Priority of Thread is:"+t1.getPriority());
        System.out.println("Priority of Thread is:"+t2.getPriority());
        System.out.println("Priority of Thread is:"+t3.getPriority());
        
        System.out.println("------------------------------");
        
        System.out.println("Current name of the Thread is-->"+Thread.currentThread().getName());
        System.out.println("------------------------------------");
        System.out.println("Priority of Current Thread is-->"+Thread.currentThread().getPriority());
        System.out.println("---------------------------------");
        Thread.currentThread().setPriority(10);
        System.out.println("Priority of Current thread is-->"+Thread.currentThread().getPriority());
    }
}
