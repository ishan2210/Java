package Multi_threading;
class Thread_8 implements Runnable
{
    Thread obj;
    public Thread_8()
    {
        obj=new Thread(this);
        obj.start();
    }
    @Override
    public void run()
    {
       try
       {
          for(int i=1;i<=5;i++)
          {
              System.out.println("Value of i is-->"+i);
              Thread.sleep(500);
          }
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
    }
}
public class multithreading_runnable_single_class {
   public static void main(String args[])
   {
       Thread_8 obj=new Thread_8();
       Thread_8 obj1=new Thread_8();
   }
}
