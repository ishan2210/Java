package Multi_threading;
class Thread_20 implements Runnable
{
    Thread obj;
    public Thread_20()
    {
        obj=new Thread(this);
        System.out.println("Thread 1-->"+obj.getName());
        obj.setName("ishan");
        System.out.println("Thread 1-->"+obj.getName());
        System.out.println("Thread 2-->"+obj.getName());
        obj.setName("Kansara");
        System.out.println("Thread 2-->"+obj.getName());
        obj.start();
    }
    @Override
    public void run()
    {
        try
        {
            System.out.println("Ishan Kansara");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
            
}

public class multithreading_get_set_name {
    public static void main(String args[])
    {
        Thread_20 obj=new Thread_20();
    }
}
