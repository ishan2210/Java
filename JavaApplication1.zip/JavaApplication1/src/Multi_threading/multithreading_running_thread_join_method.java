package Multi_threading;
class Thread_12 implements Runnable
{
    Thread obj;
    public Thread_12()
    {
            
    }
    @Override
    public void run()
    {
        try
        {
          for(int i=1;i<=5;i++)
          {
              System.out.println("Value of i is-->"+i);
              Thread.sleep(500);
          }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
class Thread_13 implements Runnable
{
    @Override
    public void run()
    {
        try
        {
           for(int i=1;i<=5;i++)
           {
               System.out.println("Value of J is-->"+i);
               Thread.sleep(500);
           }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
class Thread_14 implements Runnable
{
    @Override
    public void run()
    {
        try
        {
           for(int i=1;i<=5;i++)
           {
              System.out.println("Value of K is-->"+i);
              
              Thread.sleep(500);
           }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
public class multithreading_running_thread_join_method {
    public static void main(String args[])
    {
        Thread_12 obj=new Thread_12();
        Thread_13 obj1=new Thread_13();
        Thread_14 obj2=new Thread_14();
    }
}
