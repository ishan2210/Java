import java.util.*;
public class switch_case {
    
    public static void main(String args[])
    {
        int a,b;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
        
        System.out.println("1.Addition");
        System.out.println("2.Subtraction");
        System.out.println("3.Multiplication");
        System.out.println("4.Division");
        
        int choice;
        System.out.println("Enter your choice");
        choice=s.nextInt();
        
        switch(choice)
        {
            case 1:
                System.out.println("Addition is-->"+(a+b));
                break;
                
            case 2:
                System.out.println("Subtraction is-->"+(a-b));
                break;
                
            case 3:
                System.out.println("Multiplication is-->"+(a*b));
                break;
                
            case 4:
                System.out.println("Division is-->"+(a/b));
                break;
                
            default:
                System.out.println("Entered Choice is Invalid");
        }
    }
    
}
