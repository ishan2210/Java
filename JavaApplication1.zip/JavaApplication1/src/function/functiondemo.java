package function;
        
public class functiondemo
{
    void abc()
    {
        System.out.println("Ishan Kansara");
    }
    
    public static void main(String args[])
    {
        System.out.println("Hello World");
        functiondemo obj=new functiondemo();
        obj.abc();
    }
    
}
