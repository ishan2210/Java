package function;
import java.util.*;
class demo5
{
    int a,b;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
    //No Argument with No Return Value
    void addition()
    {
        int ans;
        ans=a+b;
        System.out.println("Addition of Two Numbers"+ans);
    }
    //Argument with Return Value
    int subtraction(int x,int y)
    {
        int ans;
        ans=x-y;
        return ans;
    }
    //Function with Arguments with no Return Value
    void multiplication(int x,int y)
    {
        int ans;
        ans=x*y;
        System.out.println("Multiplication of Two Numbers-->"+ans);
    }
    //Function with Return Value with no Arguments
    int division()
    {
        int ans1;
        ans1=a/b;
       return ans1;
    }
         
}

public class all_function_demo
{
    public static void main(String args[])
    {
        System.out.println("Performing Arithmetic Operations");
        demo5 obj=new demo5();
        obj.getdata();
        obj.putdata();
        obj.addition();
        System.out.println("Value of A-->"+obj.a);
        System.out.println("Value of B-->"+obj.b);
        int ans=obj.subtraction(obj.a,obj.b);
        System.out.println("Subtraction of Two Numbers-->"+ans);
        obj.multiplication(obj.a,obj.b);
        int ans1=obj.division();
        System.out.println("Division of Two Numbers-->"+ans1);      
        
    }
    
}
