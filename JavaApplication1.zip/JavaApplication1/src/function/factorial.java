package function;
import java.util.*;
class demo6
{
    int no;
    Scanner s=new Scanner(System.in);   
    void getdata()
    {
        System.out.println("Enter the Number-->");
        no=s.nextInt();
    }
    void factorial()
    {
        int fact=1;
        for(int i=1;i<=no;i++)
        {
            fact=fact*i;
        }
        System.out.println("factorial of given number is:"+fact);
        
    } 
}
public class factorial {
    public static void main(String args[])
    {
        demo6 obj=new demo6();
        obj.getdata();
        obj.factorial();   
    }   
}
