package function;
import java.util.*;
class demo
{
    int a,b;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
     int multiplication(int x,int y)
     {
         int ans;
         ans=x*y;
         return ans;
     }
     
    
    
    
}


public class functions_with_arguments_with_retun_value {
    
    public static void main(String args[])
    {
        demo obj=new demo();
        obj.getdata();
        obj.putdata();
        
        System.out.println("Value of A is-->"+obj.a);
        System.out.println("Value of B is-->"+obj.b);
        
        int ans=obj.multiplication(obj.a, obj.b);
        System.out.println("Multiplication of two no is:"+ans);
       
    }
    
        
    
}
