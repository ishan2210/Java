package function;
import java.util.*;
//No Arguments with Return Value
class demo1
    {
        int a,b;
        Scanner s=new Scanner(System.in);
       
        
        int multiplication()
        {
            int ans;
            System.out.println("Enter the Value of A");
            a=s.nextInt();
            System.out.println("Enter the Value of B");
            b=s.nextInt();
            ans=a*b;
            System.out.println("Multiplication of Two Numbers"+ans);
            
            return ans;
            
            
        }
        
        
        
    }
public class function_with_no_arguments_with_return_value
{
    public static void main(String args[])
    {
       demo1 obj=new demo1();
       obj.multiplication();
       
            
    }
    }
    
