package function;
import java.util.*;
    class demo58
    {
        int a,b;
        Scanner s=new Scanner(System.in);
        void getdata()
        {
            System.out.println("Enter the value of A");
            a=s.nextInt();
            System.out.println("Enter the value of B");
            b=s.nextInt();
            
        }
        void putdata()
        {
            System.out.println("Value of A is"+a);
            System.out.println("Value of B is"+b);
        }
        void addition()
        {
            int c;
            c=a+b;
            System.out.println("Value of C is-->"+c);
        }
        
    }
    public class function_with_no_argument_no_returnvalue 
    {

    public static void main(String args[])
    {
        System.out.println("Addition of Two Numbers");
        
        demo58 obj=new demo58();
        obj.getdata();
        obj.putdata();
        
        System.out.println("A is:"+obj.a);
        System.out.println("B is:"+obj.b);
        
        obj.addition();
        
        
    } 
    }
    
    

