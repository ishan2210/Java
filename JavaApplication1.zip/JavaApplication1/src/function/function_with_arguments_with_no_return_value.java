package function;
import java.util.*;
class demo2
{
    int a,b;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
    //Function with Argument with No return Value
    void subtraction(int x,int y)
    {
        int ans;
        ans=x-y;
        System.out.println("Subtractiuon of Two Numbers"+ans);
    }
    
    
    
}


public class function_with_arguments_with_no_return_value {
    
    public static void main(String args[])
    {
        demo2 obj=new demo2();
        obj.getdata();
        obj.putdata();
        
        System.out.println("Value of A-->"+obj.a);
        System.out.println("Value of B-->"+obj.b);
        
        obj.subtraction(obj.a, obj.b);
        
        
    }
    
    
}
