
package function;
import java.util.*;
class A1
{
    float a,b;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the value of A");
        a=s.nextFloat();
        System.out.println("Enter the value of B");
        b=s.nextFloat();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
    void Addition()
    {
        System.out.println("Addition of Two Numbers is-->"+(a+b));
    }
    void Subtraction()
    {
        System.out.println("Subtraction of Two Number is-->"+(a-b));
    }
    
    void Multiplication()
    {
        System.out.println("Multiplication of Two Numbers is-->"+(a*b));
    }
    
    void Division()
    {
       System.out.println("Division of Two Number is-->"+(a/b));
    }
      
}

public class functiondemo2
        {
    public static void main(String args[])
    {
        System.out.println("Program to perform Addition of Two Numbers");
        A1 obj= new A1();
        obj.getdata();
        obj.putdata();
        obj.Addition();
        obj.Subtraction();
        obj.Multiplication();
        obj.Division();
        
    }
}