package function;
import java.util.*;
class maxof3
{
    int a,b,c;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
        System.out.println("Enter the value of C");
        c=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
        System.out.println("Value of C is-->"+c);
    }
    void max()
    {
       if(a>b && a>c)
       {
           System.out.println("A is Maximum");
       }
       if(b>a && b>c)
       {
           System.out.println("B is Maximum");
       }
       if(c>a && c>b)
       {
           System.out.println("C is Maximum");
       }      
    }   
}
public class findmaxusingfunction {
    
      public static void main(String args[])
    {
//        System.out.println("Program to find the Maximum of Two Number");
//        maxof3 obj=new maxof3();
//        obj.getdata();
//        obj.putdata();
//        obj.max();
        
        demo obj1=new demo();
        obj1.getdata();
        obj1.putdata();
    }    
}
