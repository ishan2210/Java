package function;
import java.util.*;
class bankaccount 
{
    Scanner s=new Scanner(System.in);
    int accountnumber,bankbalance;
    void get_account_details()
    {
       System.out.println("Enter the account number");
       accountnumber=s.nextInt();
       System.out.println("Enter the Bank Balance");
       bankbalance=s.nextInt(); 
    }
    
    void display_account_details()
    {
        System.out.println("Account Number is-->"+accountnumber);
        System.out.println("Bank Balance is-->"+bankbalance);
    } 
}
public class bank_function
{
    public static void main(String args[])
    {
        bankaccount obj= new bankaccount();
        obj.get_account_details();
        obj.display_account_details(); 
    }  
}


    
