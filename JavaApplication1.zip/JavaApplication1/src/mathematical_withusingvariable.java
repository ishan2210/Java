import java.util.*;

public class mathematical_withusingvariable {
    public static void main (String args[])
    {
        
    
    
    int a,b;
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the value of A");
    a=s.nextInt();
    System.out.println("Enter the value of B");
    b=s.nextInt();
    int c=a+b;
    System.out.println("Sum of two numbers"+c);
    
    }
}
