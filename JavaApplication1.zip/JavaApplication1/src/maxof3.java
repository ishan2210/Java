import java.util.*;
public class maxof3 {
    
    public static void main(String args[]){
        
        int a,b,c;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
        System.out.println("Enter the value of C");
        c=s.nextInt();
        if(a==b && a==c && b==c)
        {
            System.out.println("All numbers are same");
        }
        else if(a==b)
        {
            if(c>a && c>b)
            {
                System.out.println("C is Max");
            }
            else
            {
                System.out.println("A and B are same and Maximum");
            }
            
        }
        else if(b==c)
        {
            if(a>b && a>c)
            {
                System.out.println("A is Max");
            }
            else
            {
                System.out.println("B and C are same and Maximum");
            }
        }
        else if(a==c)
        {
            if(b>a && b>c)
            {
                System.out.println("B is Max");
            }
            else
            {
                System.out.println("A and C are same and Maximum");
            }
        }
        
        else
        {
            if(a>b)
            {
                if(a>c)
                {
                    System.out.println("A is Maximum");
                }
                else
                {
                    System.out.println("C is Maximum");
                }
            }
            else
            {
                if(b>c)
                {
                    System.out.println("B is Maximum");
                }
                else
                {
                    System.out.println("C is Maximum");
                }
            }
        }
    }
}
