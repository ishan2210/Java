import java.util.*;
public class weight_kggram {
    
    public static void main (String args[]) {
        
        int kilogram,gram;
        float weight;
        Scanner s=new Scanner (System.in);
        System.out.println("Enter the Weight");
        weight=s.nextFloat();
        kilogram=(int)weight;
        gram=(int)((weight-kilogram)*1000);
        System.out.println("kilogram-->"+kilogram);
       
        System.out.println("Gram-->"+gram);
        
        
                
        
        
        
    }
    
}
