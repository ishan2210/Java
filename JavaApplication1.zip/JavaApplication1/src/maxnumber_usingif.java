import java.util.*;
public class maxnumber_usingif {
    
    public static void main(String args[]){
        
        int a,b;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
        
        if(a>b){
            System.out.println("A is Maximum");
        }
        
        if(b>a){
            System.out.println("B is Maximum");
        }
        
        
        if(a==b){
            System.out.println("A and B both are Equal");
        }
    }
    
}
