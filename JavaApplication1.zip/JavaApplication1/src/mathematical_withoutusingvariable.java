import java.util.*;

public class mathematical_withoutusingvariable {
    
    public static void main(String args[])
    {
        /*int a=10;
        int b=20;
        System.out.println("Value of a is"+a);
        System.out.println("Value of b is"+b);
        System.out.println(a+" "+b);
        int c=a+b;
        
        System.out.println("Addition of a and b"+c);
*/
        
       float a,b;
       Scanner s=new Scanner(System.in);
       System.out.println("Enter the value of A");
       a=s.nextInt();
       System.out.println("Enter the value of B");
       b=s.nextInt();
     
       System.out.println("Addition of two numbers"+(a+b));
       System.out.println("Subtraction of two number"+(a-b));
       System.out.println("Multiplication of two numbers"+(a*b));
       System.out.println("Division of two numbers"+(a/b));
                      
    }
}
