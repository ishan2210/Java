/*describe abstract class shape which has three subclass say
triangle,rectangle,circl;e,define one method area() in the abstract
class and this area() in these three subclass to calculate area()
of triangle subclass should calculate area of triangle and same for 
area of circle and same for area of rectangle
*/  
package practice_progranm;
import java.util.*;
abstract class shape
{
        Scanner s=new Scanner(System.in);
        float l,w,h,b;
        float r;
    abstract void area();
}
class triangle extends shape
{
    @Override
    void area()
    {
        System.out.println("Enter the Breadth");
        b=s.nextFloat();
        System.out.println("Enter the Height");
        h=s.nextFloat();
        System.out.println("Area of Triangle-->"+0.5*b*h);
    }
}
class rectangle extends shape
{
    
    @Override
    void area()
    {
        System.out.println("Enter the Width");
        w=s.nextFloat();
        System.out.println("Enter the Length");
        l=s.nextFloat();
        System.out.println("Area of Rectangle-->"+l*w);
    }
}
class circle extends shape
{
  @Override
  void area()
  {
    System.out.println("Enter the Radius");
    r=s.nextFloat(); 
    System.out.println("Area of Circle-->"+3.14*r*r);   
  }
}
public class abstraction_shapes
{
public static void main(String args[])
{
    triangle obj2=new triangle();
    obj2.area();
    
    rectangle obj3=new rectangle();
    obj3.area();
    
    circle obj4=new circle();
    obj4.area(); 
}       
}
