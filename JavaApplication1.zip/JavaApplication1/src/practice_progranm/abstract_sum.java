/*Write a program to define abstract class, with two
methods addition() and subtraction(). addition() is abstract method.
Implement the abstract method and call that method using a program(s).*/
package practice_progranm;
import java.util.*;
abstract class sum
{
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A-->");
        a=s.nextInt();
        System.out.println("Enter the Value of B-->");
        b=s.nextInt();
    }
    int sub,a,b;
   void sub()
    {
     sub=a-b;
     System.out.println("Subtraction of Two Numbers-->"+sub);
    }
   abstract void addition();
}
public class abstract_sum extends sum {
    @Override
    void addition()
    {
        int sum=a+b;
        System.out.println("Addition"+sum);
    }
    public static void main(String args[])
    {
        sum obj;
        obj=new abstract_sum();
        obj.getdata();
        obj.sub();
        obj.addition();
    }
}
