package polymorphism;
class Animal2
{
    void eat()
    {
        System.out.println("Eating...");
    }
}
class Dog extends Animal2
{
    @Override
    void eat()
    {
        System.out.println("Eating Bread...");
    }
}
class Cat extends Animal2
{
    @Override
    void eat()
    {
        System.out.println("Eating Rat...");
    }
}
class Rat extends Animal2
{
    void eat()
    {
        System.out.println("Eating Cheese...");
    }
}
public class animal {
    public static void main(String args[])
    {
        Animal2 a;
        a=new Dog();
        a.eat();
        a=new Cat();
        a.eat();
        a=new Rat();
        a.eat();
        
    }
}
