package polymorphism;
/*class Animal1
{
    void eat()
    {
        System.out.println("Eating...");
    }
}
class Dog1 extends Animal
{
    void eat()
    {
        System.out.println("eating fruits...");
    }
}
class Cat1 extends Dog1
{
    void eat()
    {
        System.out.println("drinking milk");
    }
}
public class runtime_multilevel {
    public static void main(String args[])
    {
        Animal a1,a2,a3;
        a1=new Animal();
        a2=new Dog();
        a3=new Cat();
        a1.eat();
        a2.eat();
        a3.eat();
    }
}
*/
class Animal1
{
    void eat()
    {
        System.out.println("Animal is eating...");
    }
}
class Dog1 extends Animal1
{
    void eat()
    {
        System.out.println("Dog is eating...");
    }
}
class Cat1 extends Dog1
{
}
public class runtime_multilevel
{
    public static void main(String args[])
    {
        Animal1 a=new Cat1();
        a.eat();
        
    }
}