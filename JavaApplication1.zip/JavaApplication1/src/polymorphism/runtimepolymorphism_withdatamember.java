package polymorphism;
class Bike
{
    int speedlimit=100;
}
class Honda extends Bike
{
    int speedlimit=150;
}

public class runtimepolymorphism_withdatamember {
    public static void main(String args[])
    {
        Bike obj=new Honda();
        System.out.println(obj.speedlimit);
    }
}
