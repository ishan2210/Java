import java.util.*;

public class currencyconverter{
    
    public static void main(String args[]){
        
        int rupees;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Rupees");
        rupees=s.nextInt();
        System.out.println("2000 Notes-->"+(rupees/2000));
        System.out.println("500 Notes-->"+(rupees%2000/500));
        System.out.println("200 Notes-->"+(rupees%2000%500/200));
        System.out.println("100 Notes-->"+(rupees%2000%500%200/100));
        System.out.println("50 Notes-->"+(rupees%2000%500%200%100/50));
        System.out.println("20 Notes-->"+(rupees%2000%500%200%100%50/20));
        System.out.println("10 Notes-->"+(rupees%2000%500%200%100%50%20/10));
        System.out.println("5 Notes-->"+(rupees%2000%500%200%100%50%20%10/5));
        System.out.println("2 Notes-->"+(rupees%2000%500%200%100%50%20%10%5/2));
        System.out.println("1 Notes-->"+(rupees%2000%500%200%100%50%20%10%5%2/1));
        
        
    }
}