import java.util.*;
public class string_char {
    
    public static void main (String args[])
    {
        //String name="Ishan Kansara";
        //System.out.println("Given string is:"+name);
        
        String name;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        //name=s.next();
        name=s.nextLine();
        System.out.println("Given String is-->"+name);
        
        char ch;
        ch=name.charAt(2);
        System.out.println("Given char is-->"+ch);
        
    }
    
}
