package array;
import java.util.*;
public class maxarray {
    
    public static void main(String args[]){
        int size,max;
        
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of Memory");
        size=s.nextInt();
        int a[]=new int [size];
        int i;
        System.out.println("Enter the Array Elements:");
        for(i=0;i<size;i++)
        {
            a[i]=s.nextInt();
        }
        for(i=0;i<size;i++)
        {
            System.out.println("Array element is-->"+a[i]);
        }
        
       max=a[0];
       for(i=0;i<size;i++)
       {
           if(max<a[i])
           {
               max=a[i];
           }
          
       }
       System.out.println("Max number is-->"+max);
       
        
    }
}
