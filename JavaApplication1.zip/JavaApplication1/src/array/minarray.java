package array;
import java.util.*;
public class minarray {
    
    public static void main(String args[]){
        int size,min;
        
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of Memory");
        size=s.nextInt();
        int a[]=new int [size];
        int i;
        System.out.println("Enter the Array Elements:");
        for(i=0;i<size;i++)
        {
            a[i]=s.nextInt();
        }
        for(i=0;i<size;i++)
        {
            System.out.println("Array element is-->"+a[i]);
        }
        
       min=a[0];
       for(i=0;i<size;i++)
       {
           if(min>a[i])
           {
               min=a[i];
           }
          
       }
       System.out.println("Min number is-->"+min);
       
        
    }
}
