package array;
import java.util.*;
public class TwoDArray {
    
    public static void main(String args[])
    {
        int row,column;
        int i,j,k,l;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of Row");
        row=s.nextInt();
        System.out.println("Enter the Size of Column");
        column=s.nextInt();
        int a[][]=new int [row][column];
        System.out.println("Enter the Array Elements of Matrix1 ");
        for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                a[i][j]=s.nextInt();
            }
        }
         System.out.println("Array elements of Matrix1");
          for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                System.out.print(a[i][j]+"\t");
            }
            System.out.println("");
            
        }
        
      
        
        System.out.println("Enter the Array Elements of Matrix2");
        for(k=0;k<row;k++)
        {
            for(l=0;l<column;l++)
            {
                a[k][l]=s.nextInt();
            }
        }
       
         System.out.println("Array elements of Matrix2");
        for(k=0;k<row;k++)
        {
            for(l=0;l<column;l++)
            {
                System.out.print(a[k][l]+"\t");
            }
            System.out.println("");
            
        }
        
        
        
        
        
    }
    
}
        
        