package array;
import java.util.*;
public class arraysearching {
    
    public static void main(String args[])
    {
        int size,choice;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of Memory");
        size=s.nextInt();
        int a[]=new int[size];
        int i;
        System.out.println("Enter the Array Elements-->");
        for(i=0;i<size;i++)
        {
            a[i]=s.nextInt();
        }
        for(i=0;i<size;i++)
        {
            System.out.println("The Array Element is-->"+a[i]);
        }
        System.out.println("Enter the Choice Number-->");
        choice=s.nextInt();
        int count=0;
        for(i=0;i<size;i++)
        {
            if(a[i]==choice)
            {
                count++;
            }
        }
        if(count>0)
        {
            System.out.println("Number Exist in the Following array-->"+count);
        }
        else
        {
           System.out.println("Number doesn't exist in the following array"); 
        }
        
        
        
        
        
        
        
        
    }
}
