package array;
import java.util.*;
public class staticarray {
    
    public static void main(String args[])
    {
        
    
    //Datatype Array_name[]=new Datatype[size];
    int a[]=new int[5];
    int i;
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the Array Elements:");
    for(i=0;i<5;i++)
    {
        a[i]=s.nextInt();
    }
    for(i=0;i<5;i++)
    {
        System.out.println("Array element is:"+a[i]);
    }
    
}
}