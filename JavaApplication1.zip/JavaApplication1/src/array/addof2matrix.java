
import java.util.*;
public class addof2matrix{
    
    public static void main(String args[])
    {
        int row,column;
        int i,j;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of Row");
        row=s.nextInt();
        System.out.println("Enter the Size of Column");
        column=s.nextInt();
        int a[][]=new int [row][column];
        int b[][]=new int [row][column];
        int c[][]=new int [row][column];
        System.out.println("Enter the Array Elements of Matrix1");
        for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                a[i][j]=s.nextInt();
            }
        }
         System.out.println("Array elements of Matrix1");
          for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                System.out.print(a[i][j]+"\t");
            }
            System.out.println("");
            
        }
        
      System.out.println("Enter the Array Elements of Matrix2");
        for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                b[i][j]=s.nextInt();
            }
        }
         System.out.println("Array elements of Matrix2");
          for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                System.out.print(b[i][j]+"\t");
            }
            System.out.println("");
            
        }
          System.out.println("The Sum of Matrix is-->");
          for(i=0;i<row;i++)
          {
              for(j=0;j<column;j++)
              {
                   c[i][j]=a[i][j]+b[i][j];
                 
              }
        
          }
          for(i=0;i<row;i++)
          {
              for(j=0;j<column;j++)
              {
                  System.out.print(c[i][j]+"\t");
                  
              }
              System.out.println("");
              
          }
          
        
    }  
}
        
        