package array;
import java.util.*;
public class dynamicarray {
    
    public static void main(String args[])
    {
        int size;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the size of memory");
        size=s.nextInt();
        int a[]=new int[size];
        int i;
    
        System.out.println("Enter the Array Elements:");
        for(i=0;i<size;i++)
        {
            a[i]=s.nextInt();
        }
        for(i=0;i<size;i++)
        {
            System.out.println("Array element is:"+a[i]);
        }
        for(i=size-1;i>=0;i--)
        {
            System.out.println("Print the reverse elements-->"+a[i]);
        }
    }
}
