package encapsulation;
class Account
{
    private long acc_no;
    private String email,name;
    private float amount;

    public long getAcc_no() {
        return acc_no;
    }

    public void setAcc_no(long acc_no) {
        this.acc_no = acc_no;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }
    
}

public class bank_acc {
    public static void main(String args[])
    {
            Account obj=new Account();
            obj.setName("45678904321");
            System.out.println("Account No is-->"+obj.getName());
            obj.setName("ishankansara10@gmail.com");
            System.out.println("Email is-->"+obj.getName());
            obj.setName("Ishan");
            System.out.println("Name is-->"+obj.getName());
            obj.setName("45.7");
            System.out.println("Amount is-->"+obj.getName());   
    }
}
