
package encapsulation;

class encap
{
   public int no;
   public String name;
   
   public encap()
   {
   }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
   
}
public class encapsulation_demo {
    public static void main(String args[])
    {
        encap obj=new encap();
        obj.setName("Ishan Kansara");
        System.out.println("Name is:"+obj.getName());
        obj.setName("176");
        System.out.println("Id is:"+obj.getName());
    }
}
