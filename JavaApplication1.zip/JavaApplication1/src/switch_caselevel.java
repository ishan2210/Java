import java.util.*;
public class switch_caselevel {
    
    public static void main(String args[]){
        
        String choice;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String:");
        choice=s.next();
        
        
        switch(choice)
        {
            case "Beginner":
                    System.out.println("Level 1");
                    break;
                    
            case  "Intermediate":
            System.out.println("Level 2");
            break;
            
            case "Expert":
                System.out.println("Level 3");
                break;
                
            default:
                System.out.println("Invalid Choice");
                break;
        }
        
    }
}
