import java.util.*;
public class areaofrectangle {
    
    public static void main(String args[]){
        
        int length,breadth,area;
        Scanner s=new Scanner (System.in);
        System.out.println("Enter the Length");
        length=s.nextInt();
        System.out.println("Enter the Breadth");
        breadth=s.nextInt();
        area=length*breadth;
        System.out.println("Area of Rectangle"+area);
    }
    
}
