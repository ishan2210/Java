package abstraction;
abstract class A19
{
    void display()
    {
       System.out.println("Non Abstract Method");
    }
    abstract void show();
}
 abstract class B19 extends A19
{
    @Override
    public void show()
    {
        System.out.println("Abstract Method:1");
    }
    abstract void show1();
}
 abstract class C19 extends B19
{
    @Override
    public void show1()
    {
        System.out.println("Abstract Method:2");
    }
    abstract void show2();
}
class D19 extends C19
{
    @Override
    public void show2()
    {
        System.out.println("Abstract Method:3");
    }
}
public class multilevel_abstraction {
    public static void main(String args[])
    {
        D19 obj=new D19();
        obj.display();
        obj.show();
        obj.show1();
        obj.show2();
        
        
        
    }
}
