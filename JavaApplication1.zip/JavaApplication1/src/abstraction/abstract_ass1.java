/*Write an abstract class named Person and its two subclass named 
Student and Employee A person has a name, address, phone number, and 
email address A student has enrolment course An employee has an office
salary, and designation. Define constructors and methods for input 
and display for both classes Write a main program to give demonstration
for all
*/
package abstraction;
import java.util.*;
abstract class person
{
   String name,address,phoneno,email;
   public person(String name,String address,String phoneno,String email)
   {
       this.name=name;
       this.address=address;
       this.phoneno=phoneno;
       this.email=email;
   }
       void display()
       {
         System.out.println("Name:"+name);
         System.out.println("--------------------");
         System.out.println("Address:"+address);
         System.out.println("--------------------");
         System.out.println("Phoneno:"+phoneno);
         System.out.println("--------------------");
         System.out.println("Email:"+email);
         System.out.println("--------------------");
       }
       abstract void display1();
}
class student extends person
{
    String enroll,course;
    public student(String name,String address, String phoneno, 
            String email,String enroll, String course)
    {
        super(name,address,phoneno,email);
        this.enroll=enroll;
        this.course=course;
    }
    @Override
    void display1()
    {
        System.out.println("Enrollment No:"+enroll);
        System.out.println("--------------------");
        System.out.println("Course:"+course);
        System.out.println("--------------------");
    }
}
class employee extends person
{
    String designation,salary;
    public employee(String name,String address,String phoneno,String email,
    String designation,String salary)
    {
        super(name,address,email,phoneno);
        this.designation=designation;
        this.salary=salary;
    }
    @Override
    void display1()
    {
        System.out.println("Designation:"+designation);
        System.out.println("--------------------");
        System.out.println("Salary:"+salary);
        System.out.println("--------------------");
    }
}
public class abstract_ass1
{
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        String name,address,phoneno,email,enroll,course,designation,salary;
        System.out.print("Enter the Name-->");
        name=s.nextLine();
        System.out.print("Enter the Phone No-->");
        phoneno=s.nextLine();
        System.out.print("Enter the Address-->");
        address=s.nextLine();
        System.out.print("Enter the Email-->");
        email=s.nextLine();
        System.out.print("Enter the Enrollment No-->");
        enroll=s.nextLine();
        System.out.print("Enter the Course-->");
        course=s.nextLine();
        System.out.print("Enter the Designation-->");
        designation=s.nextLine();
        System.out.print("Enter the Salary-->");
        salary=s.nextLine();
        
        person obj;
        obj=new student(name,address,phoneno,email,enroll,course);
        obj.display();
        obj.display1();
        
        obj=new employee(name,address,phoneno,email,designation,salary);
        obj.display();
        obj.display1();       
    }
}

