package abstraction;
abstract class Bank
{
    abstract int getrateofinterest();
}
class PNB extends Bank
{
    @Override
    int getrateofinterest()
    {
        return 7;
    }
}
class Kotak extends Bank
{
    @Override
    int getrateofinterest()
    {
        return 8;
    }
}

public class Bank_Abstraction {
    public static void main(String args[])
    {
        Bank obj;
        obj=new PNB();
        System.out.println("Rate of interest-->"+obj.getrateofinterest());
        obj=new Kotak();
        System.out.println("Rate of Interest-->"+obj.getrateofinterest());
        
    }
}
