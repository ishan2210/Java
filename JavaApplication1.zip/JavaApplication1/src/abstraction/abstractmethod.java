package abstraction;
abstract class A
{
    void display()
    {
        System.out.println("Non-Abstract Class Method");
    }
    abstract void show();
}
class B extends A
{
    @Override
    public void show()
    {
        System.out.println("Abstract Method");
    }
}
public class abstractmethod {
    public static void main(String args[])
    {
        B obj=new B();
        obj.display();
        obj.show();
        
    }
}
