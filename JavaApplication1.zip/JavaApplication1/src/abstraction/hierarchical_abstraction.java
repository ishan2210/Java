package abstraction;
abstract class A22
{
    void display()
    {
        System.out.println("Non Abstract Method");
    }
    abstract void show();
}
 class B22 extends A22
{
    @Override
    public void show()
    {
        System.out.println("Abstract Method:1");
    }
   
}
class C22 extends A22
{
    @Override
    public void show()
    {
        System.out.println("Abstract Method:2");
    }
}

public class hierarchical_abstraction {
    public static void main(String args[])
    {
        C22 obj=new C22();
        B22 obj1=new B22();
        obj.show();
        obj1.show();
        obj.display();
        
    }
}
