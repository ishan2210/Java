/* The abstract vegetable class has three subclass name potato 
brinjal and tomato write a java program that demonostrate how to
establish the class heriarchy declare one instance variable of type 
string that indicate the color of vegetable create and 
display instance of these objects override the to string() 
method of object to return a string with the name of
vegetable and its color
*/
package abstraction;
abstract class vegetable1
{
    String vegetable;
   void display()
   {
       System.out.println("Vegetables");
   }
   abstract String color();
}
class potato extends vegetable1
{
    @Override
    String color()
    {
        String Str3="Brown";
        return Str3;
    }  
}
class brinjal extends vegetable1
{
    @Override
    String color()
    {
        String Str1="Purple";
        return Str1;
    }
}
class tomato extends vegetable1
{
    @Override
    String color()
    {
       String Str2="Red";
       return Str2;
    }
}
public class vegetable {
    
    public static void main(String args[])
    {
        potato obj=new potato();
       
        System.out.println("Color of Potato is-->"+obj.color());
        
        brinjal obj1=new brinjal();
        
        System.out.println("Color of Brinjal is-->"+obj1.color());
        
        tomato obj2=new tomato();
        
        System.out.println("Color of Tomato is-->"+obj2.color());
    }
    
}
