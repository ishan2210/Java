package abstraction;
/* An abstract class can have a data member, 
abstract method, method body (non-abstract method), 
constructor, and even main() method.
package abstraction;
*/
abstract class A50
{
   
   public  A50()
    {
        System.out.println("This is a Constructor");
    }
    abstract void test();
}
class B50 extends A50
{
    @Override
  public void test()
{
    System.out.println("Test Method:1");
}
  void test1()
  {
      System.out.println("Non Abstract Method");
  }
   }
public class abstract_test {
    public static void main(String args[])
    {
        A50 obj;
        obj=new B50();
        obj.test(); 
       
        
    }
}
