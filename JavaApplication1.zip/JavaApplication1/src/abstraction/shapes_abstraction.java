package abstraction;
abstract class shape
{
    void display()
    {
        System.out.println("Shape");
    }
    abstract void draw();
}
class Rectangle extends shape
{
    @Override
    public void draw()
    {
        System.out.println("Rectangle");
    }
}
class circle extends shape
{
    @Override
    public void draw()
    {
        System.out.println("Circle");
    }
}
public class shapes_abstraction {
    public static void main(String args[])
    {
        shape obj;
        
        obj=new Rectangle();
        obj.draw();
        obj=new circle();
        obj.draw();
        obj.display();
    }
    
}
