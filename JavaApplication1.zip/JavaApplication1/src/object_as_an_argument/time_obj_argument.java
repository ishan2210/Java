package object_as_an_argument;
import java.util.*;
class demo100
{
    Scanner s=new Scanner(System.in);
    int time;
    int hours,minutes,seconds;
    void getdata()
    {
        System.out.println("Enter the Hours-->");
        hours=s.nextInt();
        System.out.println("Enter the Minutes-->");
        minutes=s.nextInt();
        System.out.println("Enter the Seconds-->");
        seconds=s.nextInt();
    }
    void putdata()
    {
            System.out.println(hours+":"+minutes+":"+seconds);
    }
    void obj_time_addition(demo100 A1,demo100 A2)
    {
        hours=A1.hours+A2.hours;
        minutes=A1.minutes+A2.minutes;
        seconds=A1.seconds+A2.seconds;
       if(seconds>=60)
       {
          seconds=seconds-60;
          minutes=minutes+1;
          
         if(minutes>=60)
       {
           minutes=minutes-60;
           hours=hours+1;
       }
       }
       
       else 
       {
           if(minutes>=60)
       {
           minutes=minutes-60;
           hours=hours+1;
       }
       }
    }
}
public class time_obj_argument {
    public static void main(String args[])
    {
        demo100 obj1=new demo100();
        obj1.getdata();
        obj1.putdata();
        System.out.println("---------------------");
        
        demo100 obj2=new demo100();
        obj2.getdata();
        obj2.putdata();
        System.out.println("---------------------");
       
        demo100 obj3=new demo100();
        obj3.obj_time_addition(obj1, obj2);
        obj3.putdata();
        
        
    }  
}
