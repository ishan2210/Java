package object_as_an_argument;
import java.util.*;
class demo85
{
    int inch,feet;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Inch-->");
        inch=s.nextInt();
        System.out.println("Enter the Feet-->");
        feet=s.nextInt();
    }
    void putdata()
    {
      System.out.println(feet+"."+inch);
    }
    void obj_calc(demo85 A1,demo85 A2)
    {
        feet=A1.feet+A2.inch/12;
        inch=A1.inch+A2.inch;
        inch=inch%12;
    }
}

public class inch_obj_argument {
    public static void main(String args[])
    {
        demo85 obj1=new demo85();
        obj1.getdata();
        obj1.putdata();
        
        demo85 obj2=new demo85();
        obj2.getdata();
        obj2.putdata();
        
        demo85 obj3=new demo85();
        obj3.obj_calc(obj1, obj2);
        obj3.putdata();
        
    }
}
