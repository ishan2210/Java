package object_as_an_argument;
import java.util.*;
class demo47
{
    int hours,mins,sec;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of Hours-->");
        hours=s.nextInt();
        System.out.println("Enter the Value of Minutes-->");
        mins=s.nextInt();
        System.out.println("Enter the Value of Seconds-->");
        sec=s.nextInt();  
    }
    void putdata()
    {
        /*System.out.println("Value of Hours-->"+hours);
        System.out.println("Value of Minutes-->"+mins);
        System.out.println("Value of Seconds-->"+sec);
           */
        System.out.println(hours+":"+mins+":"+sec);
    }
    void obj_addition(demo47 A1,demo47 A2)
    {
        sec=A1.sec+A2.sec;
        mins=A1.mins+A2.mins+sec/60;
        hours=A1.hours+A2.hours+mins/60;
        mins=mins%60;
        sec=sec%60;
        
                
    }
}
public class time_obj_argument2 {
    public  static void main(String args[])
    {
        demo47 obj1=new demo47();
        obj1.getdata();
        obj1.putdata();
        demo47 obj2=new demo47();
        obj2.getdata();
        obj2.putdata();
        
        demo47 obj3=new demo47();
        obj3.obj_addition(obj1,obj2);
        obj3.putdata();
        
        
    } 
}
    
        
    

