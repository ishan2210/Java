package object_as_an_argument;
//Object as An Argument Demo
import java.util.*;
class demo99
{
    Scanner s=new Scanner(System.in);
    int a,b;
    void getdata()
    {
        System.out.println("Enter the Value of A-->");
        a=s.nextInt();
        System.out.println("Enter the Value of B-->");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
    void obj_addition(demo99 A1,demo99 A2)
    {
        a=A1.a+A2.a;
        b=A1.b+A2.b; 
    }
}
public class object_as_arg_demo {
    public static void main(String args[])
    {
        demo99 obj1=new demo99();
        obj1.getdata();
        obj1.putdata();
        
        demo99 obj2=new demo99();
        obj2.getdata();
        obj2.putdata();
        
        demo99 obj3=new demo99();
        obj3.obj_addition(obj1, obj2);
        System.out.println("--------------------------");
        System.out.println("Addition of Two Objects-->");
        obj3.putdata();
        System.out.println("--------------------------");   
    }
}
