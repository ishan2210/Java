package constructor;
class demo8
{
    int id;
    String name;
    public demo8()
    {
        
    }
    public demo8(int id,String name)
    {
       this.id=id;
       this.name=name;
    }
   
   public demo8(demo8 obj)
   {
      id=obj.id;
      name=obj.name;
   }
   void display()
   {
       System.out.println("Id is:"+id);
       System.out.println("Name is:"+name);
   }
     
}

public class copyconstructor {
    
    public static void main(String[] args)
    {
       demo8 obj=new demo8(22,"Ishan Kansara");
       //obj.display();
       demo8 obj2=new demo8(obj);
       obj2.display();
    }
    
    
}
