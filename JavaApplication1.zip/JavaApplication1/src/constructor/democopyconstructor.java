package constructor;
class democopy
{
    int id;
    String name;
    public democopy()
    {
        
    }
    public democopy(int id,String name)
    {
        this.id=id;
        this.name=name;
    }
    public democopy(democopy obj)
    {
        System.out.println("Id is:"+obj.id);
        System.out.println("Name is:"+obj.name);
    }    
}


public class democopyconstructor {
    
    public static void main(String[] args)
    {
        democopy obj=new democopy(22,"Ishan Kansara");
        democopy obj2=new democopy(obj);
    }
    
}
