package constructor;
class thiskeyword
{
    int id;
    String name;
    public thiskeyword()
    {
        System.out.println("This is a Default Constructor");
    }
    public thiskeyword(int id,String name)
    {
        this.id=id;
        this.name=name;
    }
    void display()
    {
       System.out.println("ID IS:"+id);
       System.out.println("Name is:"+name);
    }
    
}
public class demothiskeyword {
    
    public static void main(String args[])
    {
        thiskeyword obj=new thiskeyword(22,"Ishan Kansara");
        obj.display();
        
        
    }
    
    
}
