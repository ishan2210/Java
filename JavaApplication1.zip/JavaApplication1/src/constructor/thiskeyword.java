package constructor;

class demo78
{
    String name;
    int id;
    
    public demo78()
    {
        System.out.println("This is a Default Constructor");
    }
    
    public demo78(int a)
    {
        this();
        System.out.println("A is:"+a);
    }
    public demo78(int id, String name)
    {
        this(1000);
        this.id=id;
        this.name=name;
    }
    void display()
    {
        
        System.out.println("ID is:"+id);
        System.out.println("Name is:"+name);
    }
    void test()
    {
        this.display();
        System.out.println("This is a Test Method");
    }
}
public class thiskeyword {
    
    public static void main(String[] args)
    {
        demo78 obj=new demo78(22,"Ishan Kansara");
        obj.test();
    }
    
}
