package constructor;
import java.util.*;
class cons1
{
   /* void getdata()
    {
        System.out.println("Enter the Value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
        System.out.println("Enter the Value of C");
        c=s.nextInt();
    }*/
    public cons1()
    {
       System.out.println("Default Constructor");
    }
    
    public cons1(int a)
    {
        System.out.println("Value of A is-->"+a);
    }
    
    public cons1(int b,int c)
    {
        System.out.println("Value of B is-->"+b);
        System.out.println("Value of C is-->"+c);
        
    }     
}
public class defaultconstructor {
    public static void main(String args[])
    {
      int a,b,c;
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the Value of A");
      a=s.nextInt();
      System.out.println("Enter the Value of B");
      b=s.nextInt();
      System.out.println("Enter the Value of C");
      c=s.nextInt();
        //Implicit Function
        cons1 obj=new cons1();
        cons1 obj1=new cons1(a);
        cons1 obj2=new cons1(b,c);
       
        //Explicit Functiion
      /*  cons1 obj;
        obj=new cons1();
        obj=new cons1(a);
        obj=new cons1(b,c);
        */
    }    
}

