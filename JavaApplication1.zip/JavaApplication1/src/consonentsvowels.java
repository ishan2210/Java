import java.util.*;
public class consonentsvowels {
    
    public static void main(String args[])
    {
        String name;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String:");
        name=s.next();
        char ch;
        ch=name.charAt(0);
        
        if(ch=='a'||ch=='e' || ch=='i'|| ch=='o'|| ch=='u')
        {
            System.out.println("Given character is vowel");
        }
        else
        {
            System.out.println("Given character is consonent");
        }
        
        
        
        
       
        
    }
}

       
