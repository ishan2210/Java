
package inheritance;
import java.util.*;
class A2
{
    int a,b;
    void getdata()
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Value of A-->");
        a=s.nextInt();
        System.out.println("Enter the Value of B-->");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
}
class B2 extends A2
{
    void addition()
    {
        int c;
        c=a+b;
        System.out.println("Addition of Two Numbers-->"+c);
    }
}
class C2 extends B2
{
    void multiplication()
    {
        int c;
    c=a*b;
    System.out.println("Multiplication of Two Numbers-->"+c);
    }
}
public class multilevelinheritance {
    
    public static void main(String args[])
    {
        C2 obj=new C2();
        obj.getdata();
        obj.putdata();
        obj.addition();
        obj.multiplication();     
    }
}
