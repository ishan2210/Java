
package inheritance;
import java.util.*;
class A
{
    int a,b;
    void getdata()
    {
        Scanner s=new Scanner(System.in);
         System.out.println("Enter the Value of A-->");
         a=s.nextInt();
         System.out.println("Enter the Value of B-->");
         b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A:"+a);
        System.out.println("Value of B:"+b);
    }
}

class B extends A
{
    void addition()
    {
         int c;
         c=a+b;
         System.out.println("Addition of Two Numbers"+c);
    }
   
}

public class singleinheritance {
    
    public static void main(String args[])
    {
        B obj=new B();
        obj.getdata();
        obj.putdata();
        obj.addition();
    }
}
       
    


