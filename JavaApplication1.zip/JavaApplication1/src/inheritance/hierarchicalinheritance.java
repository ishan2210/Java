
package inheritance;
import java.util.*;
class A4
{
    int a,b;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A"+a);
        System.out.println("Value of B"+b);
    }
}
class B4 extends A4
{
    void addition()
    {
        int c;
        c=a+b;
        System.out.println("Addition of Two Numbers-->"+c);
    }  
}
class C4 extends A4
{
    void multiplication()
    {
        int c;
        c=a*b;
        System.out.println("Multiplication of Two Numbers-->"+c);
    }
}
public class hierarchicalinheritance 
{
    public static void main(String args[])
    {
        B4 obj=new B4();
        obj.getdata();
        obj.putdata();
        obj.addition();
        C4 obj1=new C4();
        obj1.getdata();
        obj1.putdata();
        obj1.multiplication();  
    }
    
}
