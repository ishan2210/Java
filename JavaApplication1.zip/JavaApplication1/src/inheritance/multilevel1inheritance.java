package inheritance;
import java.util.*;
class A3
{
    Scanner s=new Scanner(System.in);
    int a,b;
    void display()
    {
        System.out.println("Enter the Value of A-->");
        a=s.nextInt();
    }
}
class B3 extends A3
{
    void display1()
    {
        System.out.println("Enter the Value of B-->");
        b=s.nextInt();
    }
}
class C3 extends B3
{
    void print()
    {
        int c;
        c=a*a;
        System.out.println("Square-->"+c);
        int d;
        d=b*b*b;
        System.out.println("Cube-->"+d);
    }
    
}
public class multilevel1inheritance {
    
    public static void main(String args[])
    {
        C3 obj=new C3();
        obj.display();
        obj.display1();
        obj.print();
    }
}
