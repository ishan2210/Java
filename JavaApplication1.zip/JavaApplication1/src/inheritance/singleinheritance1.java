package inheritance;
import java.util.*;
class A1
{
    int a,b;
    void getdata()
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Value of A-->");
        a=s.nextInt();
        System.out.println("Enter the Value of B-->");
        b=s.nextInt();
    }
    void putdata()
    {
      System.out.println("Value of A:"+a);
      System.out.println("Value of B:"+b);
    }  
}
class B1 extends A1
{
   void addition()
   {
       int c;
       c=a+b;
       System.out.println("Addition of Two Numbers-->"+c);
   }
   int subtraction(int x,int y)
   {
       int c;
       c=a-b;
       return c;
   }
   void multiplication(int a,int b)
   {
       int c;
       c=a*b;
       System.out.println("Multiplication of Two Numbers-->"+c);
   }
   int division()
   {
       int c;
       c=a/b;
       return c;
       
   }
}
public class singleinheritance1 {
    
    public static void main(String args[])
    {
        B1 obj=new B1();
        obj.getdata();
        obj.putdata();
        obj.addition();
        System.out.println("Subtraction of Two Numbers-->"
        +obj.subtraction(obj.a,obj.b));
        obj.multiplication(obj.a,obj.b);
        System.out.println("Division-->"+obj.division());
        
    }
}
