package inheritance;
import java.util.*;
class A5
{
   String name;
   String Empid;
   String no;
   String City;
   Scanner s=new Scanner(System.in);
   void getdata()
   {
       System.out.println("Enter the Employee Name");
       name=s.nextLine();
       System.out.println("Enter the Employee Id");
       Empid=s.nextLine();    
   }
   void empdetails()
   {
       System.out.println("Enter the Mobile Number-->");
       no=s.next();
       System.out.println("Enter the City-->");
       City=s.next();
   }
}
class B5 extends A5
{
    void Empname()
    {
        System.out.println("Employee name is-->"+name);
        System.out.println("Employee Id is-->"+Empid);
    }
}
class C5 extends A5
{
    void Empid()
    {
        System.out.println("Mobile Number is-->"+no);
        System.out.println("City is-->"+City);
    }  
}
public class hierarchicalinheritance1 {
    
    public static void main(String args[])
    {
       B5 obj=new B5();
       obj.getdata();
       obj.Empname();
       C5 obj1=new C5();
       obj1.empdetails();
       obj1.Empid();
       
    }   
}
