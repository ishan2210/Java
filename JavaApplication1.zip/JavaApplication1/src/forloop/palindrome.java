package forloop;
import java.util.*;
public class palindrome {
    
    public static void main(String args[])
    {
        int no,i,b,sum=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Number");
        no=s.nextInt();
        for(i=no;i>0;i=i/10)
        {
            b=i%10;
            sum=sum*10+b;
            
        }
        System.out.println("Reverse the Number"+sum);
        
        if(no==sum)
        {
            System.out.println("Given no is Palindrome");
        }
        else
        {
            System.out.println("Given no is not Palindrome");
        }
        
    }
    
    
}
