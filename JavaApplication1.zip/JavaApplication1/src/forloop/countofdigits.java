package forloop;
import java.util.*;
public class countofdigits{
    public static void main(String args[])
    {
        int no,i,b,count=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter Number");
        no=s.nextInt();
        
        for(i=no;i>0;i=i/10)
        {
            count++;
         
        }
        System.out.println("Count of Digits-->"+count);
        
       
    }
    
    
}

