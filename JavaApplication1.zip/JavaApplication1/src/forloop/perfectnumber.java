package forloop;
import java.util.*;
public class perfectnumber {
    
    public static void main(String args[])
    {
        int no,i,sum=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Number-->");
        no=s.nextInt();
        for(i=1;i<no;i++)
        {
            if(no%i==0)
            {
                sum=sum+i;
            }
       }
        
        System.out.println("Sum of Factorial-->"+sum);      
        if(sum==i)
        {
            System.out.println("Given Number is Perfect");
        }
         else
        {
            System.out.println("Given number is not perfect");
        }
        
        
    }   
    
    
    
    
}

