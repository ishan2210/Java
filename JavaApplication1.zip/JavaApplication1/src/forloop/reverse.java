
package forloop;
import java.util.*;
public class reverse{
    public static void main(String args[])
    {
        int no,i,b,sum=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter Number");
        no=s.nextInt();
        
        for(i=no;i>0;i=i/10)
        {
            b=i%10;
           sum=sum*10+b;      
        }
        System.out.println("Reverse Number-->"+sum);
    }
    
    
}

