package forloop;
import java.util.*;
public class spynumber {
    
    public static void main(String args[])
    {
        int i,no,b,sum=0,mul=1;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Number-->");
        no=s.nextInt();
        
        for(i=no;i>0;i=i/10)
        {
            b=i%10;
            sum=sum+b;
            mul=mul*b;
              
        }
        System.out.println("Sum of Digits-->"+sum);
        System.out.println("Multiplication of Digits-->"+mul); 
        if(sum==mul)
        {
            System.out.println("Given Number is Spy ");
        }
        else
        {
            System.out.println("Given number is not Spy ");
        }
        
        
        
    }
    

    
}
