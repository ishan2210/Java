package forloop;
import java.util.*;
public class armstrong{
    public static void main(String args[])
    {
        int no,i,b,sum=0,count=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter Number");
        no=s.nextInt();
        for(i=no;i>0;i=i/10)
        {
            count++;
        }
        for(i=no;i>0;i=i/10)
        {
            b=i%10;
            int power=1;
            for(int j=1;j<=count;j++)
            {
                power=power*b;
            }
            sum=sum+power;      
        }
        if(sum==no)
        {
            System.out.println("Given Number is Armstrong");
        }
        else
        {
            System.out.println("Not a ArmStrong Number");
        }     
    }
    
    
}

 