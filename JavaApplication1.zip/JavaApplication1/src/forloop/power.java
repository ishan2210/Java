package forloop;
import java.util.*;


public class power {
    
    public static void main(String args[])
    {
        int a,b,i,power=1;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
        for(i=1;i<=b;i++)
        {
            power=power*a;
        }
        System.out.println(""+power);
        
    }
    
    
}
