package forloop;
import java.util.*;
public class multiplication
{
    public static void main(String args[])
    {
        int a,b,i,c=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the Value of B");
        b=s.nextInt();
        
        for(i=1;i<=b;i++)
        {
            c=c+a;
            
        }
        System.out.println("Multiplication of Two Numbers-->"+c);
        
        
        
    }
}
