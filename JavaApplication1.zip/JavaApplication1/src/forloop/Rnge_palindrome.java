package forloop;
import java.util.*;
public class Rnge_palindrome {
    
    public static void main(String args[])
    {
        int end,start,i,b,j,count=0;
        Scanner s= new Scanner(System.in);
        System.out.print("Enter the Start Number-->");
        start=s.nextInt();
        System.out.print("Enter the End Number-->");
        end=s.nextInt();
        for(j=start;j<=end;j++)
        {
            int sum=0;
            for(i=j;i>0;i=i/10)
            {
               b=i%10;
               sum=sum*10+b;
            }
            if(sum==j)
            {
                count++;
                System.out.println("Palindrome number is-->"+j);
            }    
        }
        if(count>0)
        {
            System.out.println("Count of Palindrome is"+count);
        }       
    } 
}
