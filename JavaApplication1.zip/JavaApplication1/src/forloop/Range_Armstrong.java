package forloop;
import java.util.*;
public class Range_Armstrong {
    public static void main(String args[])
    {
        int start,end,i,j,b,sum,count=0;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the start number:");
        start=s.nextInt();
        System.out.println("Enter the end number:");
        end=s.nextInt();
        for(j=start;j<=end;j++)
        {
            sum=0;
            for(i=j;i>0;i=i/10)
            {
                b=i%10;
                sum=sum+b*b*b;
            }
            if(sum==j)
            {
                count++;
                System.out.println("Armstrong number is:"+j);
            }
        }
        if(count>0)
        {
            System.out.println("Total Armstrong number is:"+count);
        }
    }
}
