import java.util.*;
public class feettometer {
    
    public static void main(String args[]){
        
        float meter,feet;
        Scanner s = new Scanner (System.in);
        System.out.println("Enter Feet");
        feet=s.nextFloat();
        
        meter=(float) (feet/3.2808399);
        System.out.println("Meter"+meter);
    }
    
}
