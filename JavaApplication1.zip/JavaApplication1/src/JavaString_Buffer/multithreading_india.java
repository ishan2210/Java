package JavaString_Buffer;
class Table2
{
    synchronized void printable(String str)
    {
        for(int i=1;i<=3;i++)
        {
            System.out.print(str);
            try
            {
                Thread.sleep(200);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
    }
class Thread_23 extends Thread
{
    Table2 obj;

    public Thread_23(Table2 obj) {
        this.obj = obj;
    }
    
    @Override
    public void run()
    {
        obj.printable("{");
    }
    
}
class Thread_24 extends Thread
{
    Table2 obj;

    public Thread_24(Table2 obj) {
        this.obj = obj;
    }
    
    @Override
    public void run()
    {
        obj.printable("India");
    }
}
class Thread_25 extends Thread
{
    Table2 obj;

    public Thread_25(Table2 obj) {
        this.obj = obj;
    }
    
    @Override
    public void run()
    {
        obj.printable("}");
    }
}
public class multithreading_india {
    public static void main(String args[])
    {
        Table2 obj=new Table2();
       Thread_23 A1=new Thread_23(obj);
       A1.start();
       try
       {
          A1.join(); 
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
       Thread_24 A2=new Thread_24(obj);
       A2.start();
       try
       {
          A2.join(); 
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
       Thread_25 A3=new Thread_25(obj);
       A3.start();
       try
       {
          A3.join(); 
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
    }
}

