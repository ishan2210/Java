
package JavaString_Buffer;
public class JavaString_Insert {
    public static void main(String args[])
    {
        StringBuffer sb=new StringBuffer("Hello");
        sb.insert(0,"Java");
        System.out.println(sb);
    }
}
