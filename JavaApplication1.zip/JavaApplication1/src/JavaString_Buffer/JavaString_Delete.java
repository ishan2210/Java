package JavaString_Buffer;
public class JavaString_Delete {
    public static void main(String args[])
    {
        StringBuffer sb=new StringBuffer("Hello");
        sb.delete(0,3);
        System.out.println(sb);
    }
    
}