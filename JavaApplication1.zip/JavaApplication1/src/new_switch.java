
import java.util.*;
public class new_switch {
    
    public static void main(String args[])
    {
        int a,b;
        
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
        
        System.out.println("+.Addition");
        System.out.println("-.Subtraction");
        System.out.println("*.Multiplication");
        System.out.println("/.Division");
        
        String choice;
        System.out.println("Enter the String:");
        choice=s.next();
        char ch;
        
        ch=choice.charAt(0);
        
        switch(ch)
        {
            case '+':
                System.out.println("Addition is-->"+(a+b));
                break;
                
            case '-':
                System.out.println("Subtraction is-->"+(a-b));
                break;
                
            case '*':
                System.out.println("Multiplication is-->"+(a*b));
                break;
                
            case '/':
                System.out.println("Division is-->"+(a/b));
                break;
                
            default:
                System.out.println("Entered Choice is Invalid");
        }
    }
    
}
