package statickeyword;
class demo22
{
    static int count;
    public demo22()
    {
        count++;
        System.out.println("Count is:"+count);
    }
}

public class demostatickeyword {
    
    public static void main(String args[])
    {
        demo22 obj=new demo22();
        demo22 obj1=new demo22();
        demo22 obj2=new demo22();
    }
}
