package statickeyword;
class staticfnc
{
   static void getdata()
   {
       System.out.println("This is a Getdata Method");
   }
   static void putdata()
   {
       System.out.println("This is a Putdata Method");
   }
}
public class staticfunction {
    
    public static void main(String args[])
    {
        staticfnc.getdata();
        staticfnc.putdata();
    }
}
/*Without an object we can call 
the object using class name in static method
in static function all the variables must be declare static*/


