package statickeyword;
class demo23
{
    static int a;
    int b;
    public demo23()
    {
        a++;
        b=a;
    }
    void display()
    {
        System.out.println("Value of A-->"+a);
        System.out.println("Value of B-->"+b);
    }
}

public class statickeyword {
    
    public static void main(String args[])
    {
       demo23 obj=new demo23();
       demo23 obj1=new demo23();
       demo23 obj2=new demo23();
       obj.display();
       obj1.display();
       obj2.display();
    }
    
}
