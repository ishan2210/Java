package statickeyword;
class demo25
{
    static //static block
    {
        System.out.println("Static Block-1");
    }
    public static void main(String args[])
    {
        System.out.println("Hello World");
    }
    static //static block
    {
        System.out.println("Static Block-2");
    }
}
