package synchronization;
class table
{
    synchronized void printable(int n)
    {
        for(int i=1;i<=10;i++)
        {
            System.out.println(n+"*"+i+"="+(n*i));
        }
            try
            {
                Thread.sleep(200);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
    }
}
class Thread11 extends Thread
{
    table obj;

    public Thread11(table obj) {
        this.obj = obj;
    }
    
    @Override
    public void run()
    {
        obj.printable(5);
    }
}
class Thread22 extends Thread
{
    table obj;

    public Thread22(table obj) {
        this.obj = obj;
    }
    
    @Override
    public void run()
    {
        obj.printable(10);
    }
}
public class synchronization_intro {
    public static void main(String args[])
    {
       table obj=new table();
       Thread11 A1=new Thread11(obj);
       Thread22 A2=new Thread22(obj);
       
       A1.start();
       A2.start();
    }
}

