package synchronization;
class Table5
{
    synchronized static void printable(int n)
    {
        for(int i=1;i<=10;i++)
        {
            System.out.println(n+"*"+i+"="+(n*i));
        }
        try
        {
            Thread.sleep(200);
        }
        catch(Exception e)
        {
           System.out.println(e);
        }
    }
}
class Thread_27 extends Thread
{
    
    @Override
    public void run()
    {
      Table5.printable(5);  
    }
}
class Thread_28 extends Thread
{
   
   @Override
   public void run()
   {
       Table5.printable(10);
   }
}
public class synchronization_static_method {
    public static void main(String args[])
    {
       Thread_27 t1=new Thread_27();
       Thread_28 t2=new Thread_28();
       t1.start();
       t2.start();
    }
}
