package synchronization;
class customer
{
    int amount=10000;
    synchronized void withdraw(int amount)
    {
        System.out.println("going to withdraw");
    if(this.amount<amount)
    {
        System.out.println("Less Balance,Deposit money");
        try
        {
            wait();
        }
        catch(Exception e)
        {
           System.out.println(e);
        }
    }
    this.amount-=amount;
        System.out.println("Withdraw Completed");
    }
    synchronized void deposit(int amount)
    {
        System.out.println("going to deposit");
        this.amount+=amount;
        System.out.println("Deposit Completed");
        notify();
    }
}
public class synchronization_interthread {
    public static void main(String args[])
    {
        /*final customer c=new customer();
        Thread obj1;
        obj1=new Thread()
        {
            @Override
            public void run()
            {
                c.withdraw(15000);
            }
        };
        obj1.start();
        Thread obj2;
        obj2=new Thread()
        {
            @Override
            public void run()
            {
                c.deposit(10000);
            }
        };
        obj2.start();*/
      final customer c=new customer();
      new Thread()
      {
          @Override
         public void run()
         {
             c.withdraw(15000);
         }
      }.start();
      new Thread()
      {
          @Override
          public void run()
          {
              c.deposit(10000);
          }
      }.start();
    }
}
