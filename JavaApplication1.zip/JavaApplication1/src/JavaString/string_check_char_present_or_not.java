package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_check_char_present_or_not {
    public static void main(String args[]) throws Exception
    {
        String str;
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        System.out.println("Enter the String-->");
        str=br.readLine();
        System.out.println("Enter the New String");
        String s1=br.readLine();
        char ch=s1.charAt(0);
        int present=0;
        for(int i=0;i<str.length();i++)
        {
            char ch1=str.charAt(i);
            if(ch1==ch)
            {
                present++;
            }
        }
        if(present>0)
        {
           System.out.println("Character is Present");
        }
        else
        {
            System.out.println("Character is not Present");
        }   
    } 
}
