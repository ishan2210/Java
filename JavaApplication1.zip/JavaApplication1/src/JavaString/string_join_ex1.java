package JavaString;
public class string_join_ex1 {
    public static void main(String args[])
    {
        String joinstring1=String.join("-","Welcome","To","Javatpoint");
        System.out.println(joinstring1);
    }
}
