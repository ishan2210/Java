package JavaString;
import java.util.Scanner;
import java.io.*;
public class string_words_count {
    public static void main(String args[]) throws Exception
    {
        String str;
        int count=1,total=0,upper=0,lower=0;
        System.out.println("Given String is-->");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(Character.isSpace(ch))
            {
                count++;
            }      
        }
         System.out.println("Total Count-->"+count);
        String s1[]=str.split(" ");
        for(int i=0;i<s1.length;i++)
        {
            
            total++;
            System.out.println(s1[i]);
            char ch=s1[i].charAt(0);
            if(Character.isUpperCase(ch))
            {
                upper++;
            }
        }
        int last=0;
        for(int i=0;i<s1.length;i++)
        {
            int length=s1[i].length()-1;
            char ch=s1[i].charAt(length);
            if(Character.isUpperCase(ch))
            {
                last++;
            }
        }
        for(int i=0;i<s1.length;i++)
        {
            int length=s1[i].length()-1;
            char ch=s1[i].charAt(length);
            if(Character.isLowerCase(ch))
            {
                lower++;
            }
        }
        System.out.println("Start with upper case-->"+upper);
        System.out.println("End with upper case-->"+last);
        System.out.println("Total Count-->"+total);   
    }
}
