package JavaString;
public class string_replace_ex1 {
  public static void main(String args[])
  {
      String str1="javapoint is a very good website";
      String replaceString=str1.replace('a','e');
      System.out.println(replaceString);
      
  }
}
