
package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_first_letter {
    public static void main(String args[]) throws Exception
    {
        String str;
        int count=1,total=0,upper=0,upper1=0,upper2=0;
        System.out.println("Enter the String-->");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(Character.isSpace(ch))
            {
                count++;
            }
        }
        System.out.println();
        
        
        
    }    
}
