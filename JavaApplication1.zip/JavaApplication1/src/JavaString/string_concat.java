package JavaString;
public class string_concat 
{
    public static void main(String args[])
    {
        String str1="Ishan";
        String str2="Kansara";
        String str3="Studynig in Charotar University";
        String str4=str1.concat(str2);
        //Concating two Strings
        System.out.println(str4);
        String str5=str1.concat(str2).concat(str3);
        System.out.println(str5);
    }  
}

