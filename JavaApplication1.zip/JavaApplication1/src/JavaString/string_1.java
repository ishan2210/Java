package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_1 {
    public static void main(String args[]) throws Exception
    {
        String str;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String-->");
        InputStreamReader is =new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        System.out.println("Given string is-->"+str);
        String s1=new String("Ishan Kansara");
        System.out.println("String is-->"+s1);
    }
}
