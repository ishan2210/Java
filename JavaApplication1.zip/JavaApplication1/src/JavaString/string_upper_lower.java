package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_upper_lower {
    public static void main(String args[]) throws Exception
    {
        String str;
        String str1="";
        System.out.println("Enter the String-->");
        InputStreamReader is= new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        int upper=0,lower=0,sp=0,space=0,digit=0;
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(Character.isLowerCase(ch) )
            {
               ch=Character.toUpperCase(ch);
               str1=str1+ch;
            }
            else if(Character.isUpperCase(ch))
            {
               ch=Character.toLowerCase(ch);
               str1=str1+ch;
            }
            else
            {
              str1=str1+"";
            }
        }
        System.out.println("GivenString is-->"+str1);
    }

}