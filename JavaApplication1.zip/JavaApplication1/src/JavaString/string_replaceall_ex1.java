package JavaString;
public class string_replaceall_ex1 {
    public static void main(String args[])
    {
        String str1="My name is Khan My name is Bob My name is sonno";
        String replaceString=str1.replaceAll("is","was");
        System.out.println(replaceString);
       
    }
    
}
