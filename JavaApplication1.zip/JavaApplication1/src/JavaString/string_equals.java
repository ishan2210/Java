package JavaString;
public class string_equals {
    public static void main(String args[])
    {
        String str1="Ishan";
        String str2="Ishan";
        String str3="Java";
        String str4="Python";
        System.out.println(str1.equals(str2));
        System.out.println(str3.equals(str4));
    }
}
