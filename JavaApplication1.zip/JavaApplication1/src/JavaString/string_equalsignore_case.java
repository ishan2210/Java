package JavaString;
public class string_equalsignore_case {
    public static void main(String args[])
    {
        String s1="Ishan";
        String s2="Ishan";
        String s3="ishan";
        String s4="kansara";
        System.out.println(s1.equalsIgnoreCase(s2));
        System.out.println(s1.equalsIgnoreCase(s3));
        System.out.println(s1.equalsIgnoreCase(s4));
    }
}
