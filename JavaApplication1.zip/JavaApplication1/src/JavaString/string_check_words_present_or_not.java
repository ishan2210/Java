package JavaString;
import java.io.*;
import java.util.*;
public class string_check_words_present_or_not {
    public static void main(String args[]) throws Exception
    {
        String str1;
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        System.out.println("Enter the string");
        str1=br.readLine();
        
        System.out.println("Enter the Words:");
        String words=br.readLine();
        int i;
        String s1[]=null;
        for(i=0;i<str1.length();i++)
        {
            s1=str1.split(" ");
        }
        int present=0;
        for(i=0;i<s1.length;i++)
        {
            System.out.println(s1[i]);
            if(s1[i].equalsIgnoreCase(words))
            {
                 present++;
            }
        }
        if(present>0)
        {
            System.out.println("The word is present");
        }
        else
        {
            str1=str1+" "+words;
            System.out.println("New String is-->"+str1);
        }   
    }
}
