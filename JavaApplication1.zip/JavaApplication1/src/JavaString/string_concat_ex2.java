package JavaString;
public class string_concat_ex2 {
    public static void main(String args[])
    {
        String str="country";
        String s="india is my".concat(str);
        System.out.println(s);
    }
    
}
