package JavaString;
public class string_length_ex2 {
public static void main(String args[])
{
    String str1="IshanKansara";
    if(str1.length()>0)
    {
        System.out.println("Length of String is:"+str1.length());
    }
    String str2="";
    if(str2.length()==0)
    {
        System.out.println("String is empty:"+str2.length());
    }
}
}
