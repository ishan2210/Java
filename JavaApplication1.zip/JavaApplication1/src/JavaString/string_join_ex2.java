package JavaString;
public class string_join_ex2 {
    public static void main(String args[])
    {
        String date=String.join("/","22","10","2002");
        String time=String.join(":","8","57","44");
        System.out.println(date);
        System.out.println(time);
    }
}
