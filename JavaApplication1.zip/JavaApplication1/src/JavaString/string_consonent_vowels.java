package JavaString;
import java.io.*;

public class string_consonent_vowels {
    public static void main(String args[]) throws Exception
    {
        String str1;
        int count=0;
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        System.out.println("Enter the String-->");
        str1=br.readLine();
        System.out.println("Given String is-->"+str1);
        for(int i=0;i<str1.length();i++)
        {
            char ch=str1.charAt(i);
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'
                    ||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
            {
                count++;
            }
            if(count>=1)
            {
                System.out.println("This is vowel");
            }
            else
            {
                System.out.println("This is not a vowel");
            }
        }   
    }  
}
