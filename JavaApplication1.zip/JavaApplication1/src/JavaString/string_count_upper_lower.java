package JavaString;
import java.io.*;
public class string_count_upper_lower {
    public static void main(String args[]) throws Exception
    {
        String str;
        System.out.println("Enter the String-->");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        
        
        
    }
}
