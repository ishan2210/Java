package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_reverse {
    public static void main(String args[]) throws Exception
    {
        String str;
        System.out.println("Enter the String-->");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        System.out.println("Given String is-->"+str);
        int length=str.length();
        String s1="";
        for(int i=length-1;i>=0;i--)
        {
            System.out.println(str.charAt(i));
            s1=s1+str.charAt(i);
        }
        
        System.out.println("Reverse String is:"+s1);
        
        if(str.equals(s1))
     {
         System.out.println("Given String is Palindrome");
     }
     else
     {
         System.out.println("Given String is not Palindrome");
     }
        
    }
}
