package JavaString;
public class string_split {
    public static void main(String args[])
    {
        String s1="Java String Split method";
        String[] words=s1.split("\\s");
        for(String w:words)
        {
          System.out.println(w);
        }
    }
}
