
package JavaString;

public class string_getbytes {
    public static void main(String args[])
    {
        String name="Bhavesh M Jain";
        byte b[]=name.getBytes();
        for(int i=0;i<name.length();i++)
        {
            System.out.println(b[i]);
        }
        String str=new String(b);
        System.out.println(str);
    }
}
