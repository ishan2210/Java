package JavaString;
public class string_contains_ex2 {
    
    public static void main(String args[])
    {
        String str="Hello Good Evening";
        boolean iscontains=str.contains("Evening");
        System.out.println(iscontains);
        System.out.println(str.contains("evening"));
    }
    
}
