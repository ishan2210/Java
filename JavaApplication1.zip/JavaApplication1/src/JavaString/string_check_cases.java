package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_check_cases
{
    public static void main(String args[]) throws Exception
    {
        String str;
        System.out.println("Enter the String-->");
        InputStreamReader is= new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        int upper=0,lower=0,sp=0,space=0,digit=0;
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(Character.isUpperCase(ch))
            {
                upper++;
            }
            else
            if(Character.isLowerCase(ch))
            {
                lower++;
            }
            else if(Character.isSpace(ch))
            {
                space++;
            }
            else if(Character.isDigit(ch))
            {
                digit++;
            }
            else
            {
                sp++;
            }
        }
        System.out.println("UpperCase are:"+upper);
        System.out.println("LoweCase are:"+lower);
        System.out.println("Spaces are:"+space);
        System.out.println("Special Characters are:"+sp);
        System.out.println("Digits are:"+digit); 
    }
}
