/*The Java String class endsWith() method checks if this string 
ends with a given suffix. It returns true if this string 
ends with the given suffix; else returns false.*/
package JavaString;

public class string_endswith {
    public static void main(String args[])
    {
        String str="Welocme to the Charusat University";
        String str2="Java by JavaTPoint";        
        
        System.out.println(str.endsWith("University"));
        System.out.println(str.endsWith("Charusat"));
        System.out.println(str2.endsWith("Point"));
      
        
    }
}
