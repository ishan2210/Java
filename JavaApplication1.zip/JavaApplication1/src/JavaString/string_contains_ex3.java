package JavaString;
public class string_contains_ex3 {
    public static void main(String args[])
    {
        String str1="Hiii my name is ishan";
        if(str1.contains("Kansara"))
        {
            System.out.println("The result is found");
        }
        else
        {
            System.out.println("Result is not found");
        }
    }
    
}
