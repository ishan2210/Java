package JavaString;

public class string_contains {
    public static void main(String args[])
    {
        String name="Hello my name is ishan kansara";
        System.out.println(name.contains("hii"));
        System.out.println(name.contains("ishan"));
        System.out.println(name.contains("Hello"));
    }
}
