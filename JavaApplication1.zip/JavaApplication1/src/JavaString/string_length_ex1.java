package JavaString;
public class string_length_ex1 {
   public static void main(String args[])
   {
       String str1="Ishan";
       String str2="kansara";
       System.out.println("string length is:"+str1.length());
       System.out.println("string length is:"+str2.length());
       
   }
}
