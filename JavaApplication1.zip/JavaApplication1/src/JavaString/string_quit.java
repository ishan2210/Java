package JavaString;
import java.io.*;
import java.util.Scanner;
public class string_quit {
    public static void main(String args[]) throws Exception
    {
        String str1;
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        System.out.println("Enter the String-->");
        str1=br.readLine();
        if(str1.equalsIgnoreCase("quit"))
        {
         
        }
        int count=0;
        
        
    }
}
