import java.util.*;
public class areaofsquare {
    
    public static void main (String args[]){
        
        int side,area;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the Length of side");
        side=s.nextInt();
        area=side*side;
        System.out.println("Area of  Sqaure is-->"+area);
    }
    
    
}
