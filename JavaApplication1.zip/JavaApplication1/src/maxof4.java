import java.util.*;
public class maxof4 {
    public static void main(String args[])
    {
          int a,b,c,d;
          Scanner s=new Scanner(System.in);
          System.out.println("Enter the value of a");
          a=s.nextInt();
          System.out.println("Enter the value of b");
          b=s.nextInt();
          System.out.println("Enter the value of c");
          c=s.nextInt();
          System.out.println("Enter the value of d");
          d=s.nextInt();
          
          if(a>b)
          {
              if(a>c)
              {
                if(a>d)
                {
                    System.out.println("A is Maximum");
                }
                else
                {
                    System.out.println("D is Maximum");
                }
                
              }
              else 
              {
                  if(c>d)
                  {
                      System.out.println("C is Maximum");
                  }
                  else
                  {
                      System.out.println("D is Maximum");
                  }
              }
          }
          else
          {
              if(b>c)
              {
                  if(b>d)
                  {
                      System.out.println("B is Maximum");
                  }
                  else
                  {
                      System.out.println("D is Maximum");
                  }
              }
              else
              {
                  if(c>d)
                  {
                      System.out.println("C is Maximum");
                  }
                  else 
                  {
                      System.out.println("D is Maximum");
                  }
                      
              }
              
          }
        
    }
}

