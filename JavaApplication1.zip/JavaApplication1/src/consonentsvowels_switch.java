import java.util.*;
public class consonentsvowels_switch {
    
    public static void main(String args[])
    {
        String name;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        name=s.next();
        char ch;
        ch=name.charAt(0);
        switch(ch)
        {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
            case 'A':
            case 'E':
            case 'I':
            case 'O':
            case 'U':
                    System.out.println("The given character is Vowel");
                    break;
                    
            default:
                System.out.println("The given character is Consonant");
                }
          }
}
