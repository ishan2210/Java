
package mypack1;

  
   
public class p1 {
    public void display()
            
    {
      System.out.println("Ishan Kansara");
    }
}
