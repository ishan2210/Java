
package mypack1;

public class p2 {
  public static void main(String args[])
  {
      p1 obj=new p1();
      obj.display();
  }
}
