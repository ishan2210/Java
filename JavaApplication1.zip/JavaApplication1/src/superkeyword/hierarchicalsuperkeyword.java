package superkeyword;
class A10
{
   public A10()
   {
       System.out.println("Hello");
   }
   public A10(int a)
   {
       System.out.println("Value of A is-->"+a);
   }
}
class B10 extends A10
{
    public B10()
    {
        System.out.println("World");
    }
    public B10(int b)
    {
        super(20);
        System.out.println("Value of B is-->"+b);
    }
}
class C10 extends A10
{
    public C10()
    {
        System.out.println("Hi");
    }
    public C10(int c)
    {
        super(20);
        System.out.println("Value of C is-->"+c);
    }
}
public class hierarchicalsuperkeyword 
{
    public static void main(String args[])
    {
        B10 obj=new B10();
        B10 obj2=new B10(10);
        C10 obj1=new C10();
        C10 obj3=new C10(30);
    }
}
