package superkeyword;
class A9
{
    public A9()
    {
        System.out.println("Hi");
    }
    public A9(int a)
    {
        System.out.println("Value of A-->"+a);
    }
}
class B9 extends A9
{
    public B9()
    {
        System.out.println("Hello");
    }
    public B9(int b)
    {
        super(10);
        System.out.println("Value of B is-->"+b);
    }
}
class C9 extends B9
{
    public C9()
    {
      System.out.println("World");  
    }
    public C9(int c)
    {
        super(20);
        System.out.println("Value of C is-->"+c);
    }
}
public class multilevelsuperkeyword {
    
    public static void main(String args[])
    {
        C9 obj=new C9();
        C9 obj1=new C9(30);
    }
    
}
