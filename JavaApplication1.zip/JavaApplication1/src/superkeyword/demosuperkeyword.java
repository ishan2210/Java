package superkeyword;
class A8
{
    public A8()
    {
        System.out.println("This is a Base Class Constructor");
    }
    public A8(int a)
    {
        this();//to call base class default constructor
        System.out.println("Value of A is-->"+a);
    }
}
class B8 extends A8
{
    public B8()
    {
        super();
        System.out.println("This is A Derived Class Constructor");
    }
    public B8(int b)
    {
        super(100);// to call the base class with one argument
        System.out.println("Value of B is-->"+b);
    }
    
}

public class demosuperkeyword {
    
    public static void main(String args[])
    {
        B8 obj=new B8();
        B8 obj1=new B8(10);
    }
    
}
