package superkeyword;
class A11
{
    int a;
    public A11()
    {
        System.out.println("Default");
    }
    public A11(int a)
    {
       this.a=a;
       System.out.println("Value of A is-->"+a);
    }
}
class B11 extends A11
{
    int b;
    public B11()
    {
        System.out.println("Derived");
    }
    public B11(int b)
    {
        super(200);
        this.b=b;
        System.out.println("Value of B is-->"+b);
    }
    
}
public class functionsuperkeyword {
   
    public static void main(String args[])
    {
        B11 obj=new B11();
        B11 obj1=new B11(100);      
    }
    
}
