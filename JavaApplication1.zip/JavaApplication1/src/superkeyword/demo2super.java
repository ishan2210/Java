package superkeyword;
class Person
{
    int id;
    String name;
    Person(int id,String name)
    {
        this.id=id;
        this.name=name;
    }
}
class Employee extends Person
{
    float salary;
    Employee(int id,String name,float salary)
    {
        super(id,name);//reading parent class
        this.salary=salary;
    }
    void display()
    {
        System.out.println("Id is-->"+id);
        System.out.println("Name is-->"+name);
        System.out.println("Salary is-->"+salary);
    }
}
public class demo2super {
    public static void main(String args[])
    {
       Employee obj=new Employee(176,"Ishan",2500);
       obj.display();
    }
}
