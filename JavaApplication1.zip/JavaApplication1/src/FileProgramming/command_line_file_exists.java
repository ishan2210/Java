
package FileProgramming;
import java.io.*;
public class command_line_file_exists {
    public static void main(String args[])
    {
        String path=args[0];
        File fout=new File(path);
        if(fout.exists())
        {
            System.out.println("Exists");
        }
        else
        {
            System.out.println("Doesnot Existsss");
        }
    }
}
