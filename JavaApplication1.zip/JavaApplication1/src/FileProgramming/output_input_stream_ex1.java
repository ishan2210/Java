package FileProgramming;
import java.io.*;
public class output_input_stream_ex1 {
    public static void main(String args[]) throws Exception
    {
        
       //OutputStream
       FileOutputStream fout=new FileOutputStream("C:\\Users\\Ishan\\Desktop//sp.txt");
       BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       System.out.println("Enter the String");
       String name=br.readLine();
       
       byte b[]=name.getBytes();
       fout.write(b);
       fout.close();
       
       //InputStream
       FileInputStream fout2=new FileInputStream("C:\\Users\\Ishan\\Desktop//sp.txt");
       int i;
       String str="";
       int upper=0,lower=0,sp=0,space=0,digit=0;
       while((i=fout2.read())!=-1 )
       {
            
        
           char b1=(char)i;
           if(Character.isLowerCase(b1))
           {
               lower++;
           }
           else
           if(Character.isUpperCase(b1))
           {
               upper++;
           }
           else if(Character.isSpace(b1))
           {
               space++;
           }
           else if(Character.isDigit(b1))
           {
               digit++;
           }
           else 
           {
               sp++;
           }  
       }
           System.out.println("Upper case is-->"+upper);
           System.out.println("Digit is-->"+digit);
           System.out.println("Lower is-->"+lower);
           System.out.println("Special character is-->"+sp);
           System.out.println("Space is-->"+space); 
           fout2.close();
       }
    }

