package FileProgramming;
import java.io.*;
public class output_stream
{
    public static void main(String args[]) throws Exception
    {
       
        FileOutputStream fout=new FileOutputStream("C:\\Users\\Ishan\\Desktop//ishan.txt");
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the String:");
        String name=br.readLine();
        
        byte b[]=name.getBytes();
        fout.write(b);
        fout.close();
        
    }
}