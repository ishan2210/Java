package FileProgramming;

import java.io.*;

public class love_php {

    public static void main(String args[])throws Exception

    {

        FileOutputStream fout=new FileOutputStream("C:\\Users\\Ishan\\Desktop\\php.txt");

        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter the string:");

        String name=br.readLine();

        byte b[]=name.getBytes();

        fout.write(b);

        fout.close();

       

        

        FileInputStream fin=new FileInputStream("C:\\Users\\Ishan\\Desktop\\php.txt");

        int i;

        String str="";

        while((i=fin.read())!=-1)

        {

            System.out.println((char)i);

            str=str+(char)i;

            //char b1=(char)i;

            //String replaceString=str.replace("Php","Java");       

        }

        System.out.println(str);

        String s2="";

        String s1[]=str.split(" ");

        int count=0;

        for(i=0;i<s1.length;i++)

        {

            System.out.println(s1[i]);

            if(s1[i].equalsIgnoreCase(("Php")))

            {

                count++;

                s1[i]="Java";

                s2=s2+s1[i]+" ";

            }

            else

            {

                s2=s2+s1[i]+" ";

            }

        }

        System.out.println("New String is:"+s2);

        System.out.println("Total No of replacement:"+count);

    }

}