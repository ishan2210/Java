package FileProgramming;
import java.io.*;
public class upper_lower {
    public static void main(String args[]) throws Exception
    {
        FileOutputStream fout=new FileOutputStream("C:\\Users\\Ishan\\Desktop\\uprlwr.txt");
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the String-->");
        String name=br.readLine();
        
        byte b[]=name.getBytes();
        fout.write(b);
        fout.close();
        
        FileInputStream fout1=new FileInputStream("C:\\Users\\Ishan\\Desktop\\uprlwr.txt");
        int i;
        String str="";
        while((i=fout1.read())!=-1)
        {
            char b1=(char)i;
            if(Character.isLowerCase(b1))
            {
               b1=Character.toUpperCase(b1);
               str=str+b1;
            }
            else if(Character.isUpperCase(b1))
                {
                    b1=Character.toLowerCase(b1);
                    str=str+b1; 
                }
            else
            {
                str=str+"";
            }
        }
        System.out.println("Given String is-->"+str);
        fout1.close();
        
       
        FileOutputStream fout2=new FileOutputStream("C:\\Users\\Ishan\\Desktop\\uprlwr1.txt");
        byte b1[]=str.getBytes();
        fout2.write(b1);
        fout2.close();
        
    }
}
