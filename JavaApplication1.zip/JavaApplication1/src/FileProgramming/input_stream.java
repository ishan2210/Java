package FileProgramming;
import java.io.*;
public class input_stream 
{
    public static void main(String args[]) throws Exception
    {
        
            FileInputStream fin=new FileInputStream("C:\\Users\\Ishan\\Desktop//ishan.txt");
        int i;
        String str="";
        while((i=fin.read())!=-1)
        {
            System.out.println((char)i);
            str=str+(char)i;
        }
        System.out.println("Given String is:"+str);
        fin.close();
        
        
      
        
    }    
}
