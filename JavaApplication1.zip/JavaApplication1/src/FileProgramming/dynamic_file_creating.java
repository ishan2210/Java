package FileProgramming;
import java.io.*;
public class dynamic_file_creating {
    public static void main(String args[]) throws Exception
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the File");
        String file_name=br.readLine();
        
        String path="C:\\Users\\Ishan\\Desktop\\"+file_name;
        
        FileOutputStream fout=new FileOutputStream(path);
        System.out.println("Enter the String-->");
        String name=br.readLine();
        byte b[]=name.getBytes();
        fout.write(b);
        fout.close();
        
    }
}
