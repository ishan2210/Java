package FileProgramming;
import java.io.*;
public class quit_check_words {
    public static void main(String args[]) throws Exception
    {
        FileOutputStream fout=new FileOutputStream("C:\\Users\\Ishan\\Desktop//ishan.txt");
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the String:");
        String name=br.readLine();
        
        byte b[]=name.getBytes();
        fout.write(b);
        fout.close();
        
        FileInputStream fin=new FileInputStream("C:\\Users\\Ishan\\Desktop\\ishan.txt");
        int i;
        int sum=0;
        String str="";
        while((i=fin.read())!=-1)
        {
            System.out.println((char)i);
            str=str+(char)i;
        }
        System.out.println(str);
        
        do
        {
            if(str.equalsIgnoreCase("quit"))
            {
                break;
            }
          int count=0;
          for(i=0;i<str.length();i++)
          {
              char ch=str.charAt(i);
              if(str.startsWith("e"))
              {
                  count++;
              }
              else if(str.startsWith("A"))
              {
                  count++;
              }
          }
          System.out.println("Given count is-->"+count);
          System.out.println("Given String is-->"+str);
          sum=sum+count;
        }
        while(str!="quit");
        System.out.println("Sum is"+sum);
        }
}
