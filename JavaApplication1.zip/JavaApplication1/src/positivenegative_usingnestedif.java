import java.util.*;
public class positivenegative_usingnestedif {
    
    public static void main(String args[]){
        
        int number;
        Scanner s=new Scanner(System.in);
        
        System.out.println("Enter the number");
        number=s.nextInt();
        
        if(number>0){
            System.out.println("Nuber is Positive");
        }
        
        else if(number<0){
            System.out.println("Number is Negative");
        }
        
        else if(number==0){
            System.out.println("Number is 0");
        }
        
    }
    
}
