package String_Program;
import java.util.*;
import java.io.*;
public class String_Character_Present_or_not 
{
    public static void main(String args[])throws Exception
    {
        String str;
        int count=0;
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the value of string ");
        str=br.readLine();
        System.out.println("Givem String is "+str);
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the character ");
        String s1=br.readLine();
        char ch=s1.charAt(0);
        for(int i=0;i<str.length();i++)
        {
            char ch1=str.charAt(i);
            if(ch1==ch)
            {
                count++;
            }
        }
        if(count>=1)
        {
            System.out.println("Character is present");
        }
        else
        {
            System.out.println("Character is not present");
        }
    }
}
