package String_Program;
import java.io.*;
public class String_is_present 
{
    public static void main(String args[])throws Exception
    {
        String str;
        int count=0;
        System.out.println("Enter the value of string ");
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        str=br.readLine();
        System.out.println("Given string is "+str);
        System.out.println("Enter the words ");
        String words=br.readLine();
        String s1[]=null;
        for(int i=0;i<str.length();i++)
        {
            s1=str.split(" ");
        }
        for(int i=0;i<s1.length;i++)
        {
            System.out.println(s1[i]);
            if(s1[i].equalsIgnoreCase(words))
            {
                count++;
            }
        }
        if(count>0)
        {
            System.out.println("Word/s is/are present");
        }
        else
        {
            str=str+" "+words;
            System.out.println("New string is "+str);
        }
    }
}
