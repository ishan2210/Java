package String_Program;
import java.io.*;
public class String_count 
{
    public static void main(String args[])throws Exception
    {
        String str;
        int i;
        System.out.println("Enter the value of string ");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        System.out.println("Given string is "+str);
        int upper=0,lower=0,sp=0,digit=0,space=0;
        for(i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            
            if(Character.isUpperCase(ch))
            {
                upper++;
            }
            else if(Character.isLowerCase(ch))
            {
                lower++;
            }
            else if(Character.isDigit(ch))
            {
                digit++;
            }
            else if(Character.isSpace(ch))
            {
                space++;
            }
            else
            {
                sp++;
            }
        }
        System.out.println("Upper case characters are "+upper);
        System.out.println("Lower case characters are "+lower);
        System.out.println("Digits are "+digit);
        System.out.println("Spaces are "+space);
        System.out.println("Special character are "+sp);
    }
}
