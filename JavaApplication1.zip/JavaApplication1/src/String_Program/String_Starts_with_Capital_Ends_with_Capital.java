package String_Program;
import String.*;
import java.io.*;
public class String_Starts_with_Capital_Ends_with_Capital 
{
    public static void main(String args[])throws Exception
    {
        String str;
        System.out.println("Enter the string:");
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        str=br.readLine();
        int count=1,upper=0,lower=0;
        for(int i=0;i<str.length();i++)
        {
            char ch= str.charAt(i);
            if(Character.isSpace(ch))
            {
                count++;
            }
        }
        System.out.println("Total number of words:"+count);
        int i,total=0;
        String s1[]=str.split(" ");
        for(i=0;i<s1.length;i++)
        {
            total++;
            System.out.println(s1[i]);
            char ch=s1[i].charAt(0);
            if(Character.isUpperCase(ch))
            {
                upper++;
            }
        }
        int last=0;
        for(i=0;i<s1.length;i++)
        {
            int length=s1[i].length()-1;
            char ch=s1[i].charAt(length);
            if(Character.isUpperCase(ch))
            {
                last++;
            }
        }
        for(i=0;i<s1.length;i++)
        {
            int length=s1[i].length()-1;
            char ch=s1[i].charAt(length);
            if(Character.isLowerCase(ch))
            {
                lower++;
            }
        }
        System.out.println("Start with Uppercase :"+upper);
        System.out.println("End with lower case "+lower);
        System.out.println("End with upper case "+last);
    }
}
