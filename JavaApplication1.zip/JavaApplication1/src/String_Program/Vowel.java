package String_Program;
import java.io.*;
public class Vowel 
{
    public static void main(String args[])throws Exception
    {
        String str;
        int count=0;
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the value of string ");
        str=br.readLine();
        System.out.println("Given string is "+str);
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
            {
                count++;
            }
        }
        if(count>=1)
        {
            System.out.println("Vowel is present "+count+" times");
        }
        else
        {
            System.out.println("Vowel is not present");
        }
    }
}
