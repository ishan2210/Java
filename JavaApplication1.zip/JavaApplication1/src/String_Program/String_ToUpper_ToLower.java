package String_Program;
import java.io.*;
public class String_ToUpper_ToLower 
{
    public static void main(String args[])throws Exception
    {
        String str,str1="";
        int i;
        System.out.println("Enter the string ");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        System.out.println("Given string is "+str);
        for(i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(Character.isUpperCase(ch))
            {
                ch=Character.toLowerCase(ch);
                str1=str1+ch;
            }
            else if(Character.isLowerCase(ch))
            {
                ch=Character.toUpperCase(ch);
                str1=str1+ch;
            }
            else
            {
                str1=str1+" ";
            }
        }
        System.out.println(str1);
        String ch1="";
        for(i=str.length()-1;i>=0;i--)
        {
            ch1=ch1+str1.charAt(i);
        }
        System.out.println(ch1);
    }
}
