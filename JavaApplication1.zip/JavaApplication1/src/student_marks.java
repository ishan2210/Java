
import java.util.*;
public class student_marks {
    
    public static void main(String args[]){
        
        Scanner s=new Scanner (System.in);
        int a,b,c;
        System.out.println("Enter the Marks of Maths");
        a=s.nextInt();
        System.out.println("Enter the Marks of Science");
        b=s.nextInt();
        System.out.println("Enter the Marks of English");
        c=s.nextInt();
        
        int sum=a+b+c;
       System.out.println("The Total Marks of 3 Subjects "+sum);
       
       float avg=(float)sum/3;
       System.out.println("Average marks of 3 Subjects "+avg);
       
        
    }
    
}
