package return_object_as_an_argument;
import java.util.*;
class return_obj
{
    int a,b;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Value of A-->");
        a=s.nextInt();
        System.out.println("Enter the Value of B-->");
        b=s.nextInt();
    }
    void putdata()
    {
        System.out.println("Value of A is-->"+a);
        System.out.println("Value of B is-->"+b);
    }
    return_obj obj_addition(return_obj A1,return_obj A2)
    {
        return_obj A3=new return_obj();
        A3.a=A1.a+A2.a;
        A3.b=A1.b+A2.b;
        return A3;
    }
}
public class return_as_argument {
    public static void main(String args[])
    {
        return_obj obj1=new return_obj();
        obj1.getdata();
        obj1.putdata();
        
        return_obj obj2=new return_obj();
        obj2.getdata();
        obj2.putdata();
        
        return_obj obj3=new return_obj();
        obj3=obj3.obj_addition(obj1,obj2);
        System.out.println("--------------------");
        System.out.println("Addition of Two object using Argument");
        obj3.putdata();
        
    }
}
