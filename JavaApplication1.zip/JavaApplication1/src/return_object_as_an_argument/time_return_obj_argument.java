package return_object_as_an_argument;
import java.util.*;
class demo73
{
    int hours,mins,sec;
    Scanner s=new Scanner(System.in);
    void getdata()
    {
        System.out.println("Enter the Hours-->");
        hours=s.nextInt();
        System.out.println("Enter the Minutes-->");
        mins=s.nextInt();
        System.out.println("Enter the Seconds-->");
        sec=s.nextInt();
    }
    void putdata()
    {
        System.out.println(hours+":"+mins+":"+sec);
    }
    demo73 obj_add(demo73 A1 ,demo73 A2)
    {
       demo73 A3=new demo73();
        A3.sec=sec=A1.sec+A2.sec;
       A3.mins=mins=A1.mins+A2.mins+sec/60;
        A3.hours=hours=A1.hours+A2.hours+mins/60;
        A3.mins=mins=mins%60;
        A3.sec=sec=sec%60;
        return A3;
    }
}


public class time_return_obj_argument {
   public static void main(String args[])
   {
       demo73 obj1=new demo73();
       obj1.getdata();
       obj1.putdata();
       
       demo73 obj2=new demo73();
       obj2.getdata();
       obj2.putdata();
       
       demo73 obj3=new demo73();
       obj3=obj3.obj_add(obj1, obj2);
       System.out.println("Addition of Objects");
       obj3.putdata();
       
       
       
   }
}
