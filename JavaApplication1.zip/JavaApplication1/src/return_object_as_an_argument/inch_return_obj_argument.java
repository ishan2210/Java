package return_object_as_an_argument;
import java.util.*;
class demo
{
    Scanner s=new Scanner(System.in);
    int inch,feet;
    void getdata()
    {
      System.out.print("Enter the Inch-->");  
      inch=s.nextInt();
      System.out.print("Enter the Feet-->");
      feet=s.nextInt();
      System.out.println("---------------");
    }
    void putdata()
    {
        System.out.println(feet+"."+inch);
    }
    demo obj_inch(demo A1,demo A2)
    {
        demo A3=new demo();
        A3.inch=inch=A1.inch+A2.inch;
        A3.feet=feet=A1.feet+A2.feet+inch/12;
        A3.inch=inch%12;
        return A3;
    }
}
public class inch_return_obj_argument {
    public static void main(String args[])
    {
        demo obj1=new demo();
        obj1.getdata();
        obj1.putdata();
        demo obj2=new demo();
        obj2.getdata();
        obj2.putdata();
        
        demo obj3=new demo();
        obj3=obj3.obj_inch(obj1, obj2);
        System.out.println("--------------");
        obj3.putdata();
        
    }
}
