//No argument that creates default Rectangle
class Rectangle
{
    double height;
    double width;
//A constructor that creates rectangle with specified Width and Height
    Rectangle()
    {
        height=20;
        width=20;
    }
//A method named getarea() that returns the area of this rectangle
    double getarea()
    {
        return (height*width);
    }
//A method named getperimeter() that returns the Perimeter
    double getperimeter()
    {
        return (2*(height+width));
    }
}

public class Rectangle1
{
    public static void main(String args[])
    {
        Rectangle obj=new Rectangle();
        double getperimeter=obj.getperimeter();
        double getarea=obj.getarea();
        System.out.println("Value of Perimeter-->"+getperimeter);
        System.out.println("Value of Getarea-->"+getarea);
    }
}
