import java.util.*;
public class swappingwithout3rdvariable {
    
    public static void main(String args[]){
        int a,b;
          Scanner s=new Scanner (System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
        a=a+b;
        b=a-b;
        a=a-b;
        System.out.println("Swap number A-->"+a);
        System.out.println("Swap number B-->"+b);
    }
    
}
