
import java.util.*;
public class celsius_to_fahrenheit {
    
    public static void main(String args[]){
        
        float fahrenheit,celsius;
        Scanner s=new Scanner (System.in);
        System.out.println("Enter the value in Celsius-->");
        celsius=s.nextFloat();
        fahrenheit = (float) ((1.8*celsius)+32);
        System.out.println("Value of Fahrenheit-->"+fahrenheit);
        
    }
    
}
