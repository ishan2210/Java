import java.util.*;
public class torrent_bill {
    
    public static void main(String args[])
    {
        
        int units,presentreading,previousreading,choice,phase;
        float answer,FPPPA,sum,energycharges,total,dues,total1;
        Scanner s=new Scanner (System.in);
        
        System.out.println("Torrent Power");
        System.out.println("Presenting the all new Torrent Power Bill");
        
        System.out.println("Enter the present reading-->");
        presentreading=s.nextInt();
        
        System.out.println("Enter the previous reading-->");
        previousreading=s.nextInt();
        
        //PresentReading-PreviousReading=Units used in one Month
        units=(presentreading-previousreading)/2;
        System.out.println("Consumption of Units in one month-->"+units);
        
        
        System.out.println("Select the type of Traffic Structure");
        System.out.println("1.RGP");
        System.out.println("2.GLP");
        System.out.println("3.BPL");
        System.out.println("4.Non-RGP");
        
        System.out.println("Enter your Choice");
        choice=s.nextInt();
        
        //Select the type of Traffic Structure
        if(choice==1)
        {
            System.out.println("Your Traffic Structure is RGP");
            //For RGP
            answer=(float) (50*3.20+(units-50)*3.95)*2;

            FPPPA=(float) (2.11*units*2);

            System.out.println("Enter the Phase Details");
            phase=s.nextInt();

            if(phase==1)
            {
                phase=25*2;
                System.out.println("Fixed Charges-->"+phase);
            }
            else if(phase==2)
            {
                phase=65*2;
                System.out.println("Fixed Charges-->"+phase);
            }
            energycharges=(answer+phase+FPPPA);
            sum=((energycharges)*15/100);

            System.out.println("Enter Previous Dues");
            dues=s.nextFloat();

            total=energycharges+sum;
            total1=energycharges+sum+dues;

            System.out.println("Bill Details");
            System.out.println("Energy Charges-->"+answer);
            System.out.println("FPPPA Charges"+FPPPA);
            System.out.println("Fixed Charges-->"+phase);
            System.out.println("Total Energy Charges without Government Duty-->" +energycharges);
            System.out.println("Govt Duty-->"+sum);
            System.out.println("Billing amount including GST"+total);
            System.out.println("Previous dues-->"+dues);
            System.out.println("Amount Due"+total1);
        }
        else if(choice==2)
        {
            System.out.println("Your Traffic Structure is GLP");
        }
        else if(choice==3)
        {
            System.out.println("Your Traffic Structure is BPL");
        }
        else if(choice==4)
        {
            System.out.println("Your Traffic Structure is Non-RGP");
        } 
        else {
            System.out.println("Entered Choice is Invalid");
        }
        
        
            
    }   
}
