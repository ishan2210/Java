package methodoverriding;
class A18
{
    void display()
    {
        System.out.println("This is A Display Methodd");
    }  
}
class B18 extends A18
{
    @Override
    void display()
    {
        System.out.println("This is B Display Method");
    }
}
class C18 extends A18
{
    @Override
    void display()
    {
        System.out.println("This is C Display Method");
    }
}     
public class hierarchical_methodoverriding {
    public static void main(String args[])
    {
       A18 obj;
       obj=new A18();
       obj.display();
       
       obj=new B18();
       obj.display();
       
       obj=new C18();
       obj.display();
    }
}
