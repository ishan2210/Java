package methodoverriding;
class A22
{
    void display()
    {
        System.out.println("A class Display() Method");
    }
}
class B22 extends A22
{
    @Override
    void display()
    {
        
        System.out.println("B class Display() Method");
    }
}

public class single_methodoverriding {
    public static void main(String args[])
    {
        A22 obj;
        obj=new A22();
        obj.display();
        
        obj=new B22();
        obj.display();
    }
}
