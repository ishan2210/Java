package methodoverriding;
class A17
{
    void display()
    {
        System.out.println("A class Display Method");
    }
}
class B17 extends A17
{
    @Override
    void display()
    {
        System.out.println("B class Display Method");
    }
}
class C17 extends B17
{
    @Override
    void display()
    {
        System.out.println("C class Display Method");
    }
}
public class multilevel_methodoverriding {
    public static void main(String args[])
    {
        A17 obj;
        obj=new A17();
        obj.display();
        
        obj=new B17();
        obj.display();
        
        obj=new C17();
        obj.display();
    }
}
