package methodoverriding;
class Bank
{
   float getrateofinterest()
   {
      
       System.out.println("Banks Rate of Interest");
       return 0;
   }
}
class Axis extends Bank
{
    @Override
    float getrateofinterest()
    {
        
        return 11;
    }
}
class ICICI extends Bank
{
    @Override
    float getrateofinterest()
    {
        
        return 12;
    }
}
class SBI extends Bank
{
    @Override
    float getrateofinterest()
    {
        
        return 10;
    }
}
public class bank_methodoverriding {
   public static void main(String args[])
   {
       Bank obj;
       obj=new Bank();
       obj.getrateofinterest();
       obj=new Axis();
       obj.getrateofinterest();
       System.out.println("Axis Rate of Interset-->"+obj.getrateofinterest());
      
       obj=new ICICI();
       obj.getrateofinterest();
       System.out.println("ICICI Rate of Interest-->"+obj.getrateofinterest());
       
       
       obj=new SBI();
       obj.getrateofinterest();
       System.out.println("SBI Rate of Interest-->"+obj.getrateofinterest());
   }
}
