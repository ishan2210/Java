package inner_class;
class outer
{
  class inner
  {
      void show()
      {
          System.out.println("Inner class");
      }
  }
  void display()
  {
      inner obj=new inner();
      obj.show();
  }
}
public class member_inner_class {
    public static void main(String args[])
    {
        outer obj=new outer();
        obj.display();
    }
}
