package inner_class;
abstract class a1
{
    abstract void show();
}
public class anonymous_inner_abstract {
    public static void main(String args[])
    {
        a1 obj=new a1()
        {
            @Override
            void show()
            {
                System.out.println("Display Method");
            }
        };
        obj.show();
    }
}
