
package inner_class;
class outer1
{
    class inner1
    {
        void display()
        {
            System.out.println("Display Method");
        }
    }
}
public class member_inner_class2 {
    public static void main(String args[])
    {
        outer1 obj=new outer1();
        outer1.inner1 obj_in=obj.new inner1();
        obj_in.display();
    }
}
