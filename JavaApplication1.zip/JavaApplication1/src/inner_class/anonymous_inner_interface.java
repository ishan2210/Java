
package inner_class;
interface a2
{
    void display();
}

public class anonymous_inner_interface {
    public static void main(String args[])
    {
        a2 obj=new a2()
        {
            @Override
            public void display()
            {
             System.out.println("Display Method");
            }
        };
        obj.display();
    }
}
