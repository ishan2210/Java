import java.util.*;
public class swapping {
    
    public static void main (String args[]){
        int a,b,temp;
        Scanner s=new Scanner (System.in);
        System.out.println("Enter the value of A");
        a=s.nextInt();
        System.out.println("Enter the value of B");
        b=s.nextInt();
        temp=a;
        a = b;
        b = temp;
        System.out.println("Swap Two Numbers a and b Value of A "+a+" value of B "+b);
    }
    
}
