package instance_of;
class A6
{
}
class B6 extends A6
{
}
class C6 extends B6
{
}
public class multiple_instanceof {
    public static void main(String args[])
    {
        System.out.println("-----------------");
        A6 obj=new A6();
        System.out.println("OBJ A");
        System.out.println(obj instanceof A6);
        System.out.println(obj instanceof B6);
        System.out.println(obj instanceof C6);
        System.out.println("-----------------");
        B6 obj1=new B6();
        System.out.println("OBJ B");
        System.out.println(obj1 instanceof B6);
        System.out.println(obj1 instanceof A6);
        System.out.println(obj1 instanceof C6);
        System.out.println("-----------------");
        C6 obj2=new C6();
        System.out.println("OBJ C");
        System.out.println(obj2 instanceof B6);
        System.out.println(obj2 instanceof A6);
        System.out.println(obj2 instanceof C6);
        System.out.println("-----------------");
        
    }
}
