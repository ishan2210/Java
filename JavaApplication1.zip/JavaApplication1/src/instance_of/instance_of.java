package instance_of;
class A5
{
}
class B5 extends A5
{
}

public class instance_of {
    public static void main(String args[])
    {
        A5 obj=new A5();
        System.out.println(obj instanceof A5);
        System.out.println(obj instanceof B5);
        
        B5 obj1=new B5();
        System.out.println(obj1 instanceof B5);
        System.out.println(obj1 instanceof A5);
    }
}
