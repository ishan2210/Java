package instance_of;
class Animal
{
}
class Dog extends Animal
{
    static void method(Animal a){
        if(a instanceof Dog)
        {
          Dog d=(Dog)a;//Downcasting
          System.out.println("Huraah!Downcasting Performed");
        }
}
    }
public class downcasting_instanceof {
    public static void main(String args[])
    {
        Animal a=new Dog();
        Dog.method(a);
    }
}


