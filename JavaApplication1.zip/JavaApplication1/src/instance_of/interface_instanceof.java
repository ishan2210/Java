package instance_of;
interface printable
{
}
class A implements printable
{
    public void a()
    {
        System.out.println("Method 1");
    }
}
class B implements printable
{
    public void b()
    {
        System.out.println("Method 2");
    }
}
class C
{
    void invoke(printable p){
        if(p instanceof A)
        {
            A a=(A)p;//Downcasting
            a.a();
        }
        if(p instanceof B)
        {
            B b=(B)p;//Downcasting
            b.b();
        }
    }
}
public class interface_instanceof {
    
}
