import java.util.*;

public class fahrenheit_to_celsius {
    
    public static void main(String args[]){
        
        float fahrenheit,celsius;
        Scanner s= new Scanner (System.in);
       System.out.println("Enter the value in Fahrenheit");
       fahrenheit=s.nextFloat();
       
       celsius=(fahrenheit-32)*5/9;
       System.out.println("Value in Celsius-->>"+celsius);
       
    }
    
}
