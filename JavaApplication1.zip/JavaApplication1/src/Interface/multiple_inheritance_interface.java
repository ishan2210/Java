package Interface;
interface printable
{
   void print(); 
}
interface showable
{
    void show();
}
class A7 implements printable,showable
{
    @Override
    public void print()
    {
        System.out.println("Hello");
    }
    @Override
    public void show()
    {
        System.out.println("World");
    }
}

public class multiple_inheritance_interface {
    public static void main(String args[])
    {
        A7 obj=new A7();
        obj.print();
        obj.show();
    }
}
