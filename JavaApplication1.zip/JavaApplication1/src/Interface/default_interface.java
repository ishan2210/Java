package Interface;
interface i1
{
    void show();
   
            default void display()
    {
        System.out.println("This is a Default Method");
    }
}
class i2 implements i1
{
   @Override
    public void show()
    {
        System.out.println("Helloooooo");
    }
}

public class default_interface {
    public static void main(String args[])
    {
       i1 obj;
       obj=new i2();
       obj.display();
       obj.show();
       
    }
}
