package Interface;
interface Bank
{
    float interest();
}
class SBI implements Bank
{
    @Override
    public float interest()
    {
        return 6.7f;
    }
}
class PNB implements Bank
{
    @Override
    public float interest()
    {
        return 7.8f;
    }
}

public class bank_interface {
  public static void main(String args[])
  {
      Bank obj;
      obj=new PNB();
      System.out.println("PNB-->"+obj.interest());
      obj=new SBI();
      System.out.println("SBI-->"+obj.interest());
      
  }
}
