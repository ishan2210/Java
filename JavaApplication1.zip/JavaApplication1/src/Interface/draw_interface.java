package Interface;
interface drawable
{
    void draw();
}
class rectangle implements drawable
{
    @Override
    public void draw()
    {
        System.out.println("Drawing Rectangle");
    }
}
class circle implements drawable
{
    @Override
    public void draw()
    {
        System.out.println("Drawing Circle");
    }
}
public class draw_interface {
    public static void main(String args[])
    {
        drawable obj;
        obj=new circle();
        obj.draw();
        
    }
}
