package Interface;
interface a
{
    final static int a=20;
    void show_a();
}
interface b extends a
{
    final static int b=30;
    void show_b();
}
interface c extends b
{
    final static int c=50;
    void show_c();
}
interface d extends b,c
{
    final static int d=40;
    void show_d();  
}
class e implements d
{
    @Override
    public void show_a()
    {
        System.out.println("Enter the Value of A-->"+a);
    }
    @Override
    public void show_b()
    {
        System.out.println("Enter the Value of B-->"+b);
    }
    @Override
    public void show_c()
    {
        System.out.println("Enter the Value of C-->"+c);
    }
    @Override
    public void show_d()
    {
       System.out.println("Enter the Value of D-->"+d);
    }
}
public class interface_test1 {
    public static void main(String args[])
    {
       a obj1;
       b obj2;
       c obj3;
       d obj4;
       obj1=new e();
       obj1.show_a();
       obj2=new e();
       obj2.show_b();
       obj3=new e();
       obj3.show_c();
       obj4=new e();
       obj4.show_d(); 
    } 
}
