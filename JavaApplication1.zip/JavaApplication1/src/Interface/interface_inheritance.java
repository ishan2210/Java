package Interface;
interface printable
{
  void print();  
}
interface showable extends printable
{
    void show();
}
class A7 implements showable
{
    @Override
    public void print()
    {
       System.out.println("Printable");
    }
    @Override
    public void show()
    {
        System.out.println("Showable");
    }
}
public class interface_inheritance {
  public static void main(String args[])
  {
      A7 obj=new A7();
      obj.print();
      obj.show();
  }
}
