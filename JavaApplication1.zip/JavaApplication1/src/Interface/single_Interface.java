
package Interface;
interface I1
{
    void display();
}
class I2 implements I1
{
    @Override
    public void display()
    {
        System.out.println("Interface Method");
    }
}
public class single_Interface {
    public static void main(String args[])
    {
        I1 obj;
    obj=new I2();
    obj.display();
    }
    
}
