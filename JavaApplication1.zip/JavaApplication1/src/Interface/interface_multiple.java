package Interface;
interface printable
{
    void print();
}
interface showable
{
    void print();
}
class A3 implements printable,showable
{
    @Override
   public void print()
   {
       System.out.println("Print");
   }
}
public class interface_multiple {
   public static void main(String args[])
   {
       A3 obj=new A3();
       obj.print();
   }
}
