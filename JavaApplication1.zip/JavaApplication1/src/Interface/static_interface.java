package Interface;
interface drawable
{
    void draw();
    static int cube(int x)
    {
        return x*x*x;
    }
}
class rectangle implements drawable
{
    @Override
    public void draw()
    {
        System.out.println("Drawing Rectangle");
    }
}
public class static_interface {
   public static void main(String args[])
   {
      drawable obj;
      obj=new rectangle();
      obj.draw();
      System.out.println(drawable.cube(3)); 
   }
}
