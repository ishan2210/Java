/* write a program that illustrates interface inheritance interface
p is extended by p1 and p2 interface p12 inherits from both 
p1 and p2 each interface declare one constant and one method
class q implements p12 instantiate q and invokes each of its method 
display one of the constants
*/
package Interface;
interface p
{
    final static int a=10;
    void show_p();
}
interface p1 extends p
{
    final static int b=20;
    void show_p1();
}
interface p2 extends p
{
    final static int c=30;
    void show_p2();
}
interface p12 extends p1,p2
{
    final static int d=40;
    void show_p12();
}
class q implements p12
{
    public void show_p()
    {
        System.out.println("Value of A-->"+a);
    }
    @Override
    public void show_p1()
    {
        System.out.println("Value of B-->"+b);
    }
    @Override
    public void show_p2()
    {
        System.out.println("Value of C-->"+c);
    }
    @Override
    public void show_p12()
    {
        System.out.println("Value of D-->"+d);
    }
}
public class interface_test2 {
   public static void main(String args[])
   {
      p obj1;
      p1 obj2;
      p2 obj3;
      p12 obj4;
      obj1=new q();
      obj1.show_p();
      obj2=new q();
      obj2.show_p1();
      obj3=new q();
      obj3.show_p2();
      obj4=new q();
      obj4.show_p12();     
   }
}
