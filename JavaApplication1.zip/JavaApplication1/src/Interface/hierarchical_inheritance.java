package Interface;
interface I1
{
    void display();
}
interface I2 extends I1
{
    @Override
    void display();
}
interface I3 extends I1
{
    @Override
    void display();
}
interface I4 extends I1
{
    @Override
    void display();
}
class I5 implements I1
{
    @Override
    public void display()
    {
        System.out.println("Hierarchical Inheritance");
    }
}public class hierarchical_inheritance {
    public static void main(String args[])
    {
       I1 obj;
       obj=new I5();
       obj.display();
    }
}
