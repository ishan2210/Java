package Interface;
interface I1
{
    void display();
}
interface I2 extends I1
{
    @Override
     void display();       
}
interface I3 extends I2
{
    @Override
   void display();
}
class I4 implements I3
{
    @Override
    public void display()
    {
        System.out.println("Interface Method");
    }
}
public class multilevel_interface {
    public static void main(String args[])
    {
        I1 obj;
        obj=new I4();
        obj.display();
    }
    
}
