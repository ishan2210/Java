package com.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
public class SuccessServlet extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)
            throws IOException,ServletException
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        out.println("This is a successful servlet");
        out.println("<h2>Successfully Registered</h2>");
        
         
    }
}