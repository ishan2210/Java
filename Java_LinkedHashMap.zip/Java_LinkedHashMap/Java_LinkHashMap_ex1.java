package Java_LinkedHashMap;
import java.util.*;
public class Java_LinkHashMap_ex1 {
    public static void main(String args[])
    {
        LinkedHashMap<Integer,String> hm=new LinkedHashMap<Integer,String>();
        hm.put(101,"Ishan");
        hm.put(102,"Jay");
        hm.put(103,"Purv");
        for(Map.Entry m:hm.entrySet())
        {  
           System.out.println(m.getKey()+" "+m.getValue());  
        }
        System.out.println("---------------------------------");
        System.out.println("Keys: "+hm.keySet());  
        System.out.println("Values: "+hm.values()); 
        System.out.println("Key-Value pairs: "+hm.entrySet());
        System.out.println("---------------------------------");
        System.out.println("Before invoking remove() method: "+hm);     
        hm.remove(102);  
        System.out.println("After invoking remove() method: "+hm); 
    }
}
