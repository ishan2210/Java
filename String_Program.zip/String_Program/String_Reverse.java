package String_Program;
import java.io.*;
public class String_Reverse 
{
    public static void main(String args[])throws Exception
    {
        String str,ch="";
        int i;
        System.out.println("Enter the value of string ");
        InputStreamReader is=new InputStreamReader(System.in);
        BufferedReader br=new BufferedReader(is);
        str=br.readLine();
        System.out.println("Given String is "+str);
        int length=str.length();
        for(i=length-1;i>=0;i--)
        {
            System.out.println(str.charAt(i));
            ch=ch+str.charAt(i);
        }
        System.out.println(ch);
        if(str.equals(ch))
        {
            System.out.println("Palindrome String");
        }
        else
        {
            System.out.println("Not a Palindrome String");        
        }
    }
}
