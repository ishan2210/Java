package Java_LinkedList;
import java.util.*;
public class java_linkedlist_remove_method {
    public static void main(String args[])
    {
        LinkedList <String> ll=new LinkedList <String>();
        ll.add("Harshit");
        ll.add("Vandan");
        ll.add("Darshil");
        ll.add("Abhi");
        ll.add("Jay");
        ll.add("Purv");
        ll.add("Rushi");
        System.out.println("After listing all elements-->"+ll);
        System.out.println("--------------------------------------");
        ll.remove("Abhi");
        System.out.println("After removing an element from list-->"+ll);
        System.out.println("--------------------------------------");
        ll.remove(0);
        System.out.println("After removing the element at index 0-->"+ll);
        System.out.println("--------------------------------------");
        ll.removeFirst();
        System.out.println("Removing first elemement-->"+ll);
        System.out.println("--------------------------------------");
        ll.removeLast();
        System.out.println("Removing last element-->"+ll);
        System.out.println("--------------------------------------");
        ll.clear();
        System.out.println("Removing all the elements from the list-->"+ll);
        System.out.println("--------------------------------------");
    }
}
