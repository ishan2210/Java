package Java_LinkedList;
import java.util.*;
class Book
{
    int id;
    String name,author,publisher;
    int quantity;
    public Book(int id,String name,String author,String publisher,int quantity)
    {    
        this.id=id;
        this.name=name;
        this.author=author;
        this.publisher=publisher;
        this.quantity=quantity;
    }
}
public class java_Linkedlist_Book {
    public static void main(String args[])
    {
        LinkedList <Book> ll=new LinkedList <Book>();
        Book b1=new Book(101,"Let us C","Ishan","Kansara",3);
        Book b2=new Book(102,"Let us Java","Purv","Savaliya",4);
        Book b3=new Book(103,"Let us Python","Jay","Panchal",5);
        ll.add(b1);
        ll.add(b2);
        ll.add(b3);
        for(Book b:ll)
        {
              System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);  
        }
        
    }
}
