package Java_LinkedList;
import java.util.*;

public class javaLinkedlist_prog1 {
    public static void main(String args[])
    {
        LinkedList <String> al=new LinkedList<String>();
        al.add("Purv");
        al.add("Jay");
        al.add("Ishan");
        al.add("Abhi");
        Iterator<String> itr=al.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
    }
}
